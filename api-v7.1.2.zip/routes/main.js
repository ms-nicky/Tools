__path = process.cwd()


var express = require('express');
var router = express.Router();
const { User } = require('../MongoDB/schema');
const { loadChats, addChat } = require('../lib/livechat');


// Dashboard utama dengan live chat
router.get('/', async (req, res) => {
	if (!req.user) return res.redirect('/users/login');
	const user = await User.findOne({ username: req.user.username });
	const chats = loadChats();
	res.render('index', {
		user: user,
		username: user.username,
		apikey: user.apikey,
		limit: user.limit,
		chats: chats
	});
});

// Endpoint kirim chat
router.post('/livechat', async (req, res) => {
	if (!req.user) return res.status(401).json({ status: false, message: 'Unauthorized' });
	const { message } = req.body;
	if (!message || typeof message !== 'string' || message.trim().length === 0) {
		return res.status(400).json({ status: false, message: 'Pesan tidak boleh kosong' });
	}
	const user = await User.findOne({ username: req.user.username });
	addChat({ username: user.username, message: message.trim(), role: user.role });
	res.json({ status: true });
});



// Endpoint real-time chat fetch
router.get('/livechat', async (req, res) => {
	const chats = loadChats();
	res.json({ chats });
});

// Endpoint untuk menandai pesan sebagai 'read' (centang biru)
const { markChatRead } = require('../lib/livechat');
router.post('/livechat/read', async (req, res) => {
	const { index } = req.body;
	if (typeof index !== 'number') return res.status(400).json({ status: false, message: 'Index required' });
	markChatRead(index);
	res.json({ status: true });
});

module.exports = router
