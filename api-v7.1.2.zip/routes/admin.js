const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const router = express.Router();
const { execSync } = require('child_process');
const axios = require('axios');
const { isAuthenticated, isOwner } = require('../lib/auth');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const { User } = require('../MongoDB/schema');

// Helper: getSystemInfo
// Mengumpulkan informasi sistem (CPU, memory, uptime, network, Node version)
// Digunakan oleh endpoint admin untuk menampilkan status server.
function getSystemInfo() {
  const cpus = os.cpus();
  const load = os.loadavg();
  const memTotal = os.totalmem();
  const memFree = os.freemem();
  const uptime = os.uptime();

  const obj = {
    system: {
      platform: os.platform(),
      arch: os.arch(),
      hostname: os.hostname(),
      loadAverage: load,
      uptime
    },
    cpu: {
      model: cpus[0].model,
      cores: cpus.length,
      speed: cpus[0].speed
    },
    memory: {
      total: memTotal,
      free: memFree,
      used: memTotal - memFree
    },
    nodejs: {
      version: process.version
    },
    network: os.networkInterfaces()
  };

  // try to get root disk usage (in bytes) using df; fallback to zeros on error
  try {
    const dfOut = execSync('df -B1 /').toString().trim().split('\n')[1].replace(/\s+/g, ' ').split(' ');
    // df columns: Filesystem 1B-blocks Used Available Use% Mounted on
    const total = Number(dfOut[1]) || 0;
    const used = Number(dfOut[2]) || 0;
    const free = Number(dfOut[3]) || 0;
    obj.disk = { total, used, free };
  } catch (e) {
    obj.disk = { total: 0, used: 0, free: 0 };
  }

  return obj;
}

// Route: GET /server/info
// Fungsi: Mengembalikan informasi server dalam format JSON.
// Hanya dapat diakses oleh owner (middleware isOwner).
router.get('/server/info', isAuthenticated, isOwner, async (req, res) => {
  try {
    const info = getSystemInfo();
    // tambah jumlah user
    const userCount = await User.countDocuments();
    info.system.userCount = userCount;
    res.json(info);
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: GET /dashboard.html
// Fungsi: Menampilkan halaman dashboard admin (HTML).
// Hanya owner yang boleh melihat. Jika user bukan owner maka render halaman 404 (HTML) bukan JSON.
router.get('/dashboard.html', isAuthenticated, async (req, res) => {
  try {
    if (!req.user || req.user.role !== 'owner') {
      // Render halaman 404 menggunakan template error jika tersedia
      if (res.render) return res.status(404).render('layouts/error', { message: 'Page Not Found', error: {} });
      return res.status(404).send('Page Not Found');
    }
    // Owner dapat mengakses dashboard
    res.render('dashboard', { layout: false, bgmode: res.locals.bgmode });
  } catch (e) {
    // Jika terjadi error saat render, kembalikan 500
    console.error('Error rendering dashboard:', e);
    return res.status(500).render('layouts/error', { message: 'Server error', error: e });
  }
});

// Route: GET /fs
// Fungsi: Render halaman file manager (owner-only)
router.get('/fs', isAuthenticated, isOwner, async (req, res) => {
  try {
    res.render('filemanager', { layout: false });
  } catch (e) {
    console.error('Error rendering filemanager:', e);
    res.status(500).render('layouts/error', { message: 'Server error', error: e });
  }
});

// Route: GET /dashboard
// Fungsi: Redirect ke /admin/dashboard.html. Menggunakan middleware isOwner untuk otorisasi.
router.get('/dashboard', isAuthenticated, isOwner, async (req, res) => {
  // redirect to dashboard.html
  return res.redirect('/admin/dashboard.html');
});

// Route: GET /me
// Fungsi: Mengembalikan informasi user saat ini dari session. Digunakan untuk debug/keperluan UI.
router.get('/me', isAuthenticated, async (req, res) => {
  if (!req.user) return res.status(401).json({ status: false, message: 'Unauthorized' });
  res.json({ username: req.user.username, role: req.user.role });
});

// Route: GET /users
// Fungsi: Mengambil daftar user (username, email, role, limit). Hanya untuk owner.
router.get('/users', isAuthenticated, isOwner, async (req, res) => {
  try {
    const users = await User.find({}, 'username email role limit');
    // include default limit for computing used amount on client
    const defaultLimit = typeof global.limitCount !== 'undefined' ? global.limitCount : null;
    res.json({ status: true, users, defaultLimit });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: POST /users/:id
// Fungsi: Memperbarui data user (limit, role, password). Hanya owner yang boleh memanggilnya.
router.post('/users/:id', isAuthenticated, isOwner, async (req, res) => {
  try {
    const id = req.params.id;
    const update = {};
    if (req.body.limit !== undefined) {
      // Set limit user langsung ke nilai baru dari admin
      update.limit = Number(req.body.limit);
    }
    if (req.body.role) update.role = String(req.body.role);
    // If role upgraded to premium and admin didn't provide an explicit limit, set default premium daily limit
    if (update.role === 'premium' && update.limit === undefined) {
      update.limit = 1000; // premium default per-day limit
    }
    if (req.body.password) {
      // hash password before storing
      const hashed = await bcrypt.hash(String(req.body.password), 10);
      update.password = hashed;
    }
    await User.updateOne({ _id: id }, { $set: update });
    res.json({ status: true });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Simple file manager APIs (owner-only)
const BASE_FS_ROOT = process.cwd();

// Route: GET /fs/list
// Fungsi: Menampilkan daftar file/direktori pada path yang diberikan. Owner-only.
router.get('/fs/list', isAuthenticated, isOwner, async (req, res) => {
  try {
    const dir = req.query.dir ? path.resolve(BASE_FS_ROOT, req.query.dir) : BASE_FS_ROOT;
    if (!dir.startsWith(BASE_FS_ROOT)) return res.status(403).json({ status: false, message: 'Forbidden path' });
    const items = await fs.promises.readdir(dir, { withFileTypes: true });
    const list = items.map(i => ({ name: i.name, isDirectory: i.isDirectory() }));
    res.json({ status: true, path: path.relative(BASE_FS_ROOT, dir) || '/', list });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: GET /fs/read
// Fungsi: Membaca isi file dan mengembalikannya sebagai teks. Owner-only.
router.get('/fs/read', isAuthenticated, isOwner, async (req, res) => {
  try {
    const file = req.query.file ? path.resolve(BASE_FS_ROOT, req.query.file) : null;
    if (!file || !file.startsWith(BASE_FS_ROOT)) return res.status(403).json({ status: false, message: 'Forbidden' });
    const stat = await fs.promises.stat(file);
    if (stat.isDirectory()) return res.status(400).json({ status: false, message: 'Is a directory' });
    const data = await fs.promises.readFile(file, 'utf8');
    res.json({ status: true, file: path.relative(BASE_FS_ROOT, file), content: data });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: POST /fs/write
// Fungsi: Menulis/menimpa file dengan konten yang diberikan. Owner-only.
router.post('/fs/write', isAuthenticated, isOwner, async (req, res) => {
  try {
    const file = req.body.file ? path.resolve(BASE_FS_ROOT, req.body.file) : null;
    const content = req.body.content || '';
    if (!file || !file.startsWith(BASE_FS_ROOT)) return res.status(403).json({ status: false, message: 'Forbidden' });
    await fs.promises.writeFile(file, content, 'utf8');

    // Optional: sync writes under the `database/` folder to a GitHub repo if configured
    // NOTE: to avoid accidental repository edits, GitHub sync only runs when ENABLE_GITHUB_SYNC is set to '1'
    (async () => {
      try {
  const githubSyncEnabled = (process.env.ENABLE_GITHUB_SYNC === '1') || !!global.ENABLE_GITHUB_SYNC;
  const githubRepo = process.env.GITHUB_REPO || global.GITHUB_REPO;
  const githubToken = process.env.GITHUB_TOKEN || global.GITHUB_TOKEN || global.GH_TOMEN;
        if (!githubSyncEnabled || !githubRepo || !githubToken) return;
        const rel = path.relative(BASE_FS_ROOT, file).replace(/\\/g, '/');
        if (!rel.startsWith('database/')) return; // only sync database content
        const [owner, repo] = githubRepo.split('/');
        const ghPath = rel;
        const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(ghPath)}`;
        // try to get existing sha
        let sha = null;
        try {
          const getRes = await axios.get(apiUrl, { headers: { Authorization: `token ${githubToken}`, Accept: 'application/vnd.github+json' } });
          if (getRes && getRes.data && getRes.data.sha) sha = getRes.data.sha;
        } catch (getErr) {
          if (!(getErr.response && getErr.response.status === 404)) throw getErr;
        }
        const contentB64 = Buffer.from(content, 'utf8').toString('base64');
        const putBody = { message: `Update ${rel} via server`, content: contentB64 };
        if (sha) putBody.sha = sha;
        await axios.put(apiUrl, putBody, { headers: { Authorization: `token ${githubToken}`, Accept: 'application/vnd.github+json' } });
        // don't need to return anything; fire-and-forget success logged
      } catch (err) {
        // capture HTTP response body/status and headers for diagnosis
        const ghStatus = err && err.response && err.response.status;
        const ghBody = err && err.response && err.response.data;
        const ghHeaders = err && err.response && err.response.headers;
        console.error('GitHub sync failed for fs/write:', err && err.message, { status: ghStatus, body: ghBody, headers: ghHeaders });
        // attempt to get token diagnostics (whoami + scopes) if possible
        let whoami = null;
        try {
          const token = githubToken;
          if (token) {
            const who = await axios.get('https://api.github.com/user', { headers: { Authorization: `token ${token}`, Accept: 'application/vnd.github+json' } });
            whoami = { login: who && who.data && who.data.login, scopes: who && who.headers && (who.headers['x-oauth-scopes'] || who.headers['x-oauth-scopes'.toLowerCase()]) };
          }
        } catch (whoErr) {
          // ignore; best-effort diagnostic
        }
        try {
          const logDir = path.join(process.cwd(), 'logs');
          if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
          const logFile = path.join(logDir, 'github_sync_errors.log');
          const entry = { time: new Date().toISOString(), file: rel, status: ghStatus, error: err && err.message, body: ghBody, headers: ghHeaders, whoami };
          fs.appendFileSync(logFile, JSON.stringify(entry) + '\n');
        } catch (e) {
          // ignore logging errors
        }
      }
    })();

    res.json({ status: true });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: POST /fs/rename
// Fungsi: Mengganti nama file atau folder. Owner-only.
router.post('/fs/rename', isAuthenticated, isOwner, async (req, res) => {
  try {
    const src = req.body.src ? path.resolve(BASE_FS_ROOT, req.body.src) : null;
    const dest = req.body.dest ? path.resolve(BASE_FS_ROOT, req.body.dest) : null;
    if (!src || !dest || !src.startsWith(BASE_FS_ROOT) || !dest.startsWith(BASE_FS_ROOT)) return res.status(403).json({ status: false, message: 'Forbidden' });
    await fs.promises.rename(src, dest);
    res.json({ status: true });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: GET /fs/download
// Fungsi: Download file (owner-only)
router.get('/fs/download', isAuthenticated, isOwner, async (req, res) => {
  try {
    const file = req.query.file ? path.resolve(BASE_FS_ROOT, req.query.file) : null;
    if (!file || !file.startsWith(BASE_FS_ROOT)) return res.status(403).json({ status: false, message: 'Forbidden' });
    const stat = await fs.promises.stat(file);
    if (stat.isDirectory()) return res.status(400).json({ status: false, message: 'Is a directory' });
    return res.download(file);
  } catch (e) {
    return res.status(500).json({ status: false, message: e.message });
  }
});

// Route: POST /fs/delete
// Fungsi: Hapus file atau folder. Menerima JSON { paths: ["rel/path", ...] } atau { path: "rel/path" }
router.post('/fs/delete', isAuthenticated, isOwner, async (req, res) => {
  try {
    const payload = req.body;
    let targets = [];
    if (Array.isArray(payload.paths)) targets = payload.paths;
    else if (typeof payload.path === 'string') targets = [payload.path];
    else return res.status(400).json({ status: false, message: 'No paths provided' });

    for (const p of targets) {
      const abs = path.resolve(BASE_FS_ROOT, p || '');
      if (!abs.startsWith(BASE_FS_ROOT)) return res.status(403).json({ status: false, message: 'Forbidden path' });
      // use rm with recursive for files and folders
      await fs.promises.rm(abs, { recursive: true, force: true });
    }
    res.json({ status: true });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: POST /fs/upload
// Fungsi: Upload file into target directory. multipart/form-data with field 'file' and optional 'dir' (relative)
const uploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      const dir = req.body.dir || req.query.dir || '';
      const normalized = dir && dir.startsWith('/') ? dir.replace(/^\/+/, '') : (dir || '');
      const target = normalized ? path.resolve(BASE_FS_ROOT, normalized) : BASE_FS_ROOT;
      if (!target.startsWith(BASE_FS_ROOT)) return cb(new Error('Forbidden'));
      if (!fs.existsSync(target)) fs.mkdirSync(target, { recursive: true });
      return cb(null, target);
    } catch (err) { return cb(err); }
  },
  filename: (req, file, cb) => cb(null, file.originalname)
});
const uploadMw = multer({ storage: uploadStorage });

router.post('/fs/upload', isAuthenticated, isOwner, uploadMw.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ status: false, message: 'No file uploaded' });
    res.json({ status: true, file: path.relative(BASE_FS_ROOT, req.file.path) });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// Route: GET /admin/database
// Fungsi: Menampilkan halaman Database Anime di dalam dashboard admin
// Menampilkan "Database Anime" tab untuk manage anime images via GitHub
router.get('/database', isAuthenticated, isOwner, async (req, res) => {
  try {
    res.render('admin-database', { layout: false });
  } catch (e) {
    console.error('Error rendering admin-database:', e);
    return res.status(500).render('layouts/error', { message: 'Server error', error: e });
  }
});

module.exports = router;
