require("../settings");
const express = require('express');
const axios = require('axios');
const { Octokit } = require('@octokit/rest');
const path = require('path');
const { Buffer } = require('buffer');
const fs = require('fs');
const { isAuthenticated, isOwner } = require('../lib/auth');
const router = express.Router();

// ========== GLOBAL CONFIG ==========
const gh_token = global.GITHUB_PAT_TOKEN || global.GITHUB_TOKEN;  // Try PAT first, fallback to classic token
const gh_repo = global.GITHUB_REPO;

// GitHub Client
let octokit = null;
if (gh_token) {
  octokit = new Octokit({ auth: gh_token });
  const tokenType = global.GITHUB_PAT_TOKEN ? 'Fine-grained PAT' : 'Classic Token';
  console.log(`[Anime-Admin] GitHub Token Loaded (${tokenType}).`);
} else {
  console.warn("[Anime-Admin] WARNING: GITHUB_PAT_TOKEN atau GITHUB_TOKEN kosong. Panel TIDAK bisa edit database!");
}

// Temporary Folder (untuk simpan file sementara sebelum upload)
const uploadDir = path.join(__dirname, "..", "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

// ========== GitHub Helpers ==========
async function getDefaultBranch(owner, repo) {
  const info = await octokit.repos.get({ owner, repo });
  return info.data.default_branch || "main";
}

async function listAllJsonFiles() {
  const [owner, repo] = gh_repo.split('/');
  const branch = await getDefaultBranch(owner, repo);
  const tree = await octokit.git.getTree({
    owner,
    repo,
    tree_sha: branch,
    recursive: "1"
  });

  return tree.data.tree
    .filter(x => x.type === "blob" && x.path.endsWith(".json"))
    .map(x => ({ path: x.path, name: path.basename(x.path) }));
}

async function readJsonFromRaw(file) {
  const [owner, repo] = gh_repo.split('/');
  const branch = await getDefaultBranch(owner, repo);
  const raw = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${file}?t=${Date.now()}`;
  const res = await axios.get(raw, { timeout: 20000 });
  return res.data;
}

async function writeJsonToGitHub(file, jsonData, msg = "update via anime-admin") {
  const [owner, repo] = gh_repo.split('/');
  let sha = null;

  try {
    const exist = await octokit.repos.getContent({ owner, repo, path: file });
    sha = exist.data.sha;
  } catch (e) {
    if (e.status !== 404) throw e;
  }

  const encoded = Buffer.from(JSON.stringify(jsonData, null, 2)).toString("base64");

  return octokit.repos.createOrUpdateFileContents({
    owner,
    repo,
    path: file,
    message: msg,
    content: encoded,
    sha: sha || undefined,
    branch: await getDefaultBranch(owner, repo)
  });
}

// HELPER BARU: baca isi JSON langsung dari GitHub (HEAD), bukan dari raw URL
async function getJsonFromGitHub(file) {
  if (!gh_repo) throw new Error("GITHUB_REPO is not set");

  const [owner, repo] = gh_repo.split('/');

  if (!octokit) {
    throw new Error("GitHub client is not initialized (no token)");
  }

  try {
    const branch = await getDefaultBranch(owner, repo);

    const { data } = await octokit.repos.getContent({
      owner,
      repo,
      path: file,
      ref: branch
    });

    if (!data || data.type !== "file") return [];

    const buff = Buffer.from(data.content, data.encoding || "base64");
    const text = buff.toString("utf8");

    try {
      const parsed = JSON.parse(text);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.log(`[JSON PARSE ERROR] ${file} → ${e.message}`);
      // Kalau JSON rusak / invalid, treat sebagai kosong agar data lama tidak hidup lagi
      return [];
    }
  } catch (e) {
    if (e.status === 404) {
      // File belum ada → dianggap kosong
      return [];
    }
    throw e;
  }
}

// ========== Upload System (GitHub via lib/upload) ==========
const { uploadFile } = require("../lib/upload");

// ========== Serve Admin UI ==========
router.get("/", isAuthenticated, isOwner, (req, res) => {
  res.sendFile(path.join(__dirname, "..", "views", "anime-admin.html"));
});

// ========== API: LIST JSON FILES ==========
router.get("/api/list-files", isAuthenticated, isOwner, async (req, res) => {
  try {
    const list = await listAllJsonFiles();
    res.json({ status: true, list });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

// ========== API: READ JSON FILE ==========
router.get("/api/get-json", isAuthenticated, isOwner, async (req, res) => {
  try {
    const file = req.query.file;
    if (!file) return res.json({ status: false, message: "file required" });

    const data = await readJsonFromRaw(file);
    res.json({ status: true, data });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ========== API: FETCH TIKTOK ==========
router.post("/api/fetch-tiktok", isAuthenticated, isOwner, async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.json({ status: false, message: "url required" });

    const api = `http://localhost:44556/api/download/tiktok?url=${encodeURIComponent(url)}&apikey=${global.creator}`;
    console.log(`[FETCH TIKTOK] → ${api}`);

    const r = await axios.get(api, { timeout: 30000 });
    const d = r.data;
    const result = d.result || {};
    const images = [];

    if (result.type === "slide" && Array.isArray(result.slides)) {
      result.slides.forEach(x => images.push(typeof x === "string" ? x : (x.url || x.thumbnail)));
    } else if (result.video_nowm) {
      images.push(...(Array.isArray(result.video_nowm) ? result.video_nowm : [result.video_nowm]));
    } else if (result.cover) {
      images.push(result.cover);
    }

    if (!images.length) return res.json({ status: false, message: "Tidak ada gambar ditemukan." });

    res.json({ status: true, images });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ========== API: UPLOAD & SAVE ==========
router.post("/api/upload-and-save", isAuthenticated, isOwner, async (req, res) => {
  try {
    const { file, urls, tiktok_url } = req.body;
    if (!file || !Array.isArray(urls)) return res.json({ status: false, message: "file & urls[] required" });

    console.log(`\n=== UPLOAD START → ${file} (${urls.length} images) ===`);

    const uploaded = [];

    for (const u of urls) {
      try {
        console.log(`[DOWNLOAD] ${u}`);
        const img = await axios.get(u, { responseType: "arraybuffer" });

        const fname = `${Date.now()}-${Math.random().toString(36).slice(2)}.jpg`;
        const temp = path.join(uploadDir, fname);

        fs.writeFileSync(temp, Buffer.from(img.data));

        const { url: uploadedUrl } = await uploadFile(temp);
        uploaded.push(uploadedUrl);

        if (fs.existsSync(temp)) fs.unlinkSync(temp);
        console.log(`[OK] → ${uploadedUrl}`);
      } catch (e) {
        console.log(`[FAIL] ${u} → ${e.message}`);
      }
    }

    // DEBUG LOG biar kelihatan di console kalau sudah masuk tahap update JSON
    console.log(`[JSON] Updating ${file} with ${uploaded.length} image(s)...`);

    // BACA ISI TERBARU LANGSUNG DARI GITHUB (HEAD)
    const current = await getJsonFromGitHub(file);
    const arr = Array.isArray(current) ? [...current] : [];

    // APPEND URL baru (tidak replace)
    for (const u of uploaded) {
      arr.push({ url: u });
    }

    await writeJsonToGitHub(
      file,
      arr,
      tiktok_url
        ? `Add ${uploaded.length} new images from TikTok: ${tiktok_url}`
        : `Add ${uploaded.length} new images`
    );

    console.log(`=== DONE (${uploaded.length} uploaded to ${file}) ===\n`);
    res.json({ status: true, uploaded });
  } catch (e) {
    console.error("[UPLOAD-AND-SAVE ERROR]", e.message);
    res.json({ status: false, message: e.message });
  }
});

// ========== API: REPLACE NOMOR ==========
router.post("/api/replace-number-with-url", isAuthenticated, isOwner, async (req, res) => {
  try {
    const { nomor, url, file } = req.body;
    if (!nomor || !url || !file) return res.json({ status: false, message: "nomor, url, file required" });

    let arr = await getJsonFromGitHub(file);
    if (!Array.isArray(arr)) arr = [];

    let count = 0;
    arr = arr.map(x => {
      if (String(x.nomor) === String(nomor)) {
        count++;
        return { url };
      }
      return x;
    });

    if (!count) return res.json({ status: false, message: "Nomor tidak ditemukan." });

    await writeJsonToGitHub(file, arr, `Replace nomor ${nomor}`);
    res.json({ status: true, replaced: count });
  } catch (e) {
    console.error("[REPLACE-NOMOR ERROR]", e.message);
    res.json({ status: false, message: e.message });
  }
});

module.exports = router;
