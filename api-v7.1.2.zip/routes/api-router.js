const express = require('express');
const multer = require('multer');
const path = require('path');
const { blockIPOnUploadError } = require('../lib/ip-blocker');
const fs = require('fs');

const router = express.Router();

// Konfigurasi Multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

// Filter jenis file yang diizinkan
const fileFilter = (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|mp4/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (extname && mimetype) {
        return cb(null, true);
    } else {
        cb(new Error('Jenis file tidak diizinkan.'), false);
    }
};

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 1024 * 1024 * 50 }, // Batasan ukuran 50MB
    fileFilter: fileFilter
}).single('file'); // 'file' adalah nama field di formulir

// Endpoint POST untuk unggah pos dan file ke c.termai.cc
const { uploadFile } = require('../lib/upload');
router.post('/upload', (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            console.error('Multer error:', err);
            return res.status(500).json({ status: false, message: 'Multer error', error: err.message });
        }
        blockIPOnUploadError(null, req, res, async () => {
            if (req.file) {
                try {
                    const buffer = fs.readFileSync(req.file.path);
                    const originalFileName = req.file.originalname;
                    const mimeType = req.file.mimetype;
                    const result = await uploadFile(buffer, originalFileName, mimeType);
                    console.log('Upload result:', result);
                    let fileUrl = result.url || result.fileUrl || result.file_url || result.result?.url || null;
                    if (fileUrl) {
                        return res.status(200).json({ status: true, message: 'Upload berhasil', file_url: fileUrl });
                    } else {
                        return res.status(500).json({ status: false, message: 'Upload berhasil tapi URL tidak ditemukan', result });
                    }
                } catch (error) {
                    console.error('Upload gagal:', error);
                    return res.status(500).json({ status: false, message: 'Upload gagal', error: error.message });
                }
            } else {
                console.error('Tidak ada file yang diunggah.');
                return res.status(400).json({ status: false, message: 'Tidak ada file yang diunggah.' });
            }
        });
    });
});

module.exports = router;
