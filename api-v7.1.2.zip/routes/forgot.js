const express = require('express');
const router = express.Router();
const { User } = require('../MongoDB/schema');
const Otp = require('../MongoDB/otpModel');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

// GET: Halaman input email
router.get('/', (req, res) => {
  res.render('forgot', { layout: false });
});

// POST: Kirim OTP ke email
router.post('/', async (req, res) => {
  const { email } = req.body;
  console.log('[DEBUG] POST /forgot - email input:', email);
  console.log('[DEBUG] POST /forgot - set session.forgotEmail:', email);
  const user = await User.findOne({ email });
  if (!user) {
    req.flash('error_msg', 'Email tidak terdaftar');
    return res.redirect('/forgot');
  }
  // Generate OTP
  const otp = ('' + Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 menit
  await Otp.deleteMany({ email }); // hapus otp lama
  await Otp.create({ email, otp, expiresAt });
  // Kirim email OTP
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: global.your_email,
      pass: global.email_password
    }
  });
  const mailOptions = {
    from: global.your_email,
    to: email,
    subject: 'Kode OTP Reset Password',
    html: `<p>Kode OTP Anda: <b>${otp}</b><br>Jangan berikan kode ini ke siapapun.</p>`
  };
  try {
    await transporter.sendMail(mailOptions);
    req.flash('success_msg', 'Kode OTP telah dikirim ke email Anda');
  } catch (e) {
    // Jangan tampilkan password/email di error
    req.flash('error_msg', 'Gagal mengirim email OTP.');
  }
  req.session.forgotEmail = email;
  res.redirect('/forgot/verify');
});

module.exports = router;