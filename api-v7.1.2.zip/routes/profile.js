const express = require('express');
const validator = require('validator');
const router = express.Router();
const path = require('path');
const { isAuthenticated } = require('../lib/auth');
const { User } = require('../MongoDB/schema');
// Use main upload.js (GitHub direct upload)
const { uploadFile } = require('../lib/upload');
const bcrypt = require('bcryptjs');
const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const multer = require('multer');
const uploadDir = path.join(__dirname, '..', 'uploads', 'profile');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

function randomName(len = 6) {
  return Math.random().toString(36).substring(2, 2 + len);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, randomName() + ext);
  }
});

const upload = multer({ storage });

// POST custom apikey (khusus premium)
router.post('/custom-apikey', isAuthenticated, async (req, res) => {
  let { customApikey } = req.body;
  // Sanitasi input untuk mencegah XSS dan karakter berbahaya
  if (typeof customApikey === 'string') {
    customApikey = validator.escape(customApikey.trim());
  }
  // Owner boleh apapun, premium tetap validasi panjang
  const user = await User.findOne({ username: req.user.username });
  if (!user) {
    req.flash('error_msg', 'User tidak ditemukan');
    return res.redirect('/profile');
  }
  if (user.role !== 'owner' && (!customApikey || typeof customApikey !== 'string' || customApikey.length < 4 || customApikey.length > 32)) {
    req.flash('error_msg', 'Custom apikey harus 4-32 karakter');
    return res.redirect('/profile');
  }
  // Cek apakah apikey sudah dipakai user lain (kecuali owner ganti apikey sendiri)
  const exist = await User.findOne({ apikey: customApikey });
  if (exist && exist.username !== user.username) {
    req.flash('error_msg', 'Apikey sudah digunakan user lain');
    return res.redirect('/profile');
  }
  // Cek role user
  if (user.role !== 'premium' && user.role !== 'owner') {
    req.flash('error_msg', 'Hanya user premium atau owner yang bisa custom apikey');
    return res.redirect('/profile');
  }
  // Update apikey
  await User.updateOne({ username: req.user.username }, { apikey: customApikey });
  req.flash('success_msg', 'Custom apikey berhasil diubah!');
  res.redirect('/profile');
});

// GET profile page
router.get('/', isAuthenticated, async (req, res) => {
  const user = await User.findOne({ username: req.user.username });
  if (!user) return res.redirect('/users/login');

  // Cek role owner
  let accountType = user.role === 'owner' ? 'Owner' : (user.role === 'premium' ? 'Premium' : 'Free');
  let limit = user.role === 'owner' ? '∞' : user.limit;
  let expiredAt = 'No expiration';
  if (user.role === 'owner') {
    expiredAt = '∞';
  } else if (user.role === 'premium' && user.premium && user.premium.length > 0) {
    expiredAt = user.premium[0].expired || 'No expiration';
  }

  res.render('profile', {
    user: {
      username: user.username,
      email: user.email,
      apikey: user.apikey,
      accountType,
      role: user.role, // <-- tambahkan role
      limit,
      expiredAt,
      profilePic: user.profilePic || '/uploads/pp-default.png',
    }
  });
});

// ====== UPLOAD FOTO PROFIL ======
router.post('/upload-photo', isAuthenticated, upload.single('profilePic'), async (req, res) => {
  try {
    if (!req.file) {
      req.flash('error_msg', 'No file uploaded');
      return res.redirect('/profile');
    }

    const localPath = req.file.path;
    console.log(`[PROFILE UPLOAD] File diterima: ${localPath}`);

    // Upload ke GitHub
    let result;
    try {
      result = await uploadFile(localPath);
      console.log(`[PROFILE UPLOAD] GitHub URL: ${result.url}`);
    } catch (uploadErr) {
      console.error(`[PROFILE UPLOAD] Upload failed:`, uploadErr.message);
      if (fs.existsSync(localPath)) fs.unlinkSync(localPath);
      req.flash('error_msg', 'Gagal upload foto: ' + uploadErr.message);
      return res.redirect('/profile');
    }

    // Simpan URL ke database user (MongoDB)
    try {
      const user = await User.findOne({ username: req.user.username });
      if (!user) {
        throw new Error('User tidak ditemukan');
      }
      user.profilePic = result.url;
      await user.save();
      console.log(`[PROFILE UPLOAD] Foto profil berhasil disimpan untuk user: ${req.user.username}`);
    } catch (dbErr) {
      console.error(`[PROFILE UPLOAD] Database error:`, dbErr.message);
      req.flash('error_msg', 'Gagal menyimpan ke database: ' + dbErr.message);
      return res.redirect('/profile');
    }

    console.log(`[PROFILE UPLOAD] Foto profil berhasil diperbarui untuk user: ${req.user.username}`);
    req.flash('success_msg', 'Foto profil berhasil diperbarui! (Disimpan ke ' + result.source + ')');
    res.redirect('/profile');

  } catch (err) {
    console.error('[PROFILE UPLOAD ERROR]', err.message);
    req.flash('error_msg', 'Gagal upload: ' + err.message);
    res.redirect('/profile');
  }
});

module.exports = router;

// POST change password
router.post('/change-password', isAuthenticated, async (req, res) => {
  const { oldPassword, newPassword, confirmNewPassword } = req.body;
  if (!oldPassword || !newPassword || !confirmNewPassword) {
    req.flash('error_msg', 'Semua field wajib diisi');
    return res.redirect('/profile');
  }
  if (newPassword !== confirmNewPassword) {
    req.flash('error_msg', 'Password baru dan konfirmasi tidak sama');
    return res.redirect('/profile');
  }
  const user = await User.findOne({ username: req.user.username });
  if (!user) {
    req.flash('error_msg', 'User tidak ditemukan');
    return res.redirect('/profile');
  }
  const match = await bcrypt.compare(oldPassword, user.password);
  if (!match) {
    req.flash('error_msg', 'Password lama salah');
    return res.redirect('/profile');
  }
  const hash = await bcrypt.hash(newPassword, 10);
  await User.updateOne({ username: req.user.username }, { password: hash });
  // After changing password, log the user out so they must re-authenticate with the new password.
  try {
    if (typeof req.logout === 'function') {
      // Passport may provide req.logout()
      req.logout();
    }
  } catch (err) {
    // ignore logout errors
    console.error('Logout after password change error:', err);
  }
  // Inform user and redirect to login. Use flash so the login page can show the message.
  req.flash('success_msg', 'Password berhasil diubah. Silakan masuk kembali dengan password baru.');
  return res.redirect('/users/login');
});

// POST change email
router.post('/change-email', isAuthenticated, async (req, res) => {
  const { oldEmail, newEmail } = req.body;
  if (!oldEmail || !newEmail) {
    req.flash('error_msg', 'Semua field wajib diisi');
    return res.redirect('/profile');
  }
  const user = await User.findOne({ username: req.user.username });
  if (!user) {
    req.flash('error_msg', 'User tidak ditemukan');
    return res.redirect('/profile');
  }
  if (user.email !== oldEmail) {
    req.flash('error_msg', 'Email lama salah');
    return res.redirect('/profile');
  }
  await User.updateOne({ username: req.user.username }, { email: newEmail });
  req.flash('success_msg', 'Email berhasil diubah');
  res.redirect('/profile');
});

module.exports = router;
