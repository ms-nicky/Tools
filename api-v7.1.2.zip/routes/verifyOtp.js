const express = require('express');
const router = express.Router();
const Otp = require('../MongoDB/otpModel');

// GET: Halaman input OTP
router.get('/verify', async (req, res) => {
  console.log('[DEBUG] GET /forgot/verify - session.forgotEmail:', req.session.forgotEmail);
    const email = req.session.forgotEmail;
    // Selalu render halaman verifikasi OTP jika session email ada
    let waitTime = 0;
    if (email) {
      const otpDoc = await Otp.findOne({ email });
      if (otpDoc && otpDoc.nextReset) {
        const now = Date.now();
        if (now < otpDoc.nextReset.getTime()) {
          waitTime = Math.ceil((otpDoc.nextReset.getTime() - now)/1000);
        }
      }
      return res.render('verify-otp', { email, waitTime, success_msg: req.flash('success_msg'), error_msg: req.flash('error_msg') });
    } else {
      req.flash('error_msg', 'Email tidak ditemukan');
      return res.redirect('/forgot');
    }
});
const { User } = require('../MongoDB/schema');
const bcrypt = require('bcryptjs');

// POST: Verifikasi OTP
router.post('/verify', async (req, res) => {
  const { email, otp } = req.body;
  const otpDoc = await Otp.findOne({ email });
  if (!otpDoc) {
    req.flash('error_msg', 'OTP tidak ditemukan atau kadaluarsa');
    return res.redirect('/forgot/verify?email=' + encodeURIComponent(email));
  }
  if (otpDoc.attempts >= 3) {
    req.flash('error_msg', 'Percobaan OTP habis, silakan reset OTP');
    return res.redirect('/forgot/verify?email=' + encodeURIComponent(email));
  }
  if (otpDoc.otp !== otp) {
    otpDoc.attempts += 1;
    await otpDoc.save();
    req.flash('error_msg', 'Kode OTP salah');
    return res.redirect('/forgot/verify?email=' + encodeURIComponent(email));
  }
  // OTP benar, set session agar bisa akses reset password
  req.session.resetPasswordEmail = email;
  res.render('reset-password', { email });
});

// POST: Reset OTP
router.post('/reset-otp', async (req, res) => {
  const { email } = req.body;
  const otpDoc = await Otp.findOne({ email });
  if (!otpDoc) {
    req.flash('error_msg', 'OTP tidak ditemukan');
    return res.redirect('/forgot');
  }
  const now = Date.now();
  let waitTime = 5 * 60 * 1000 * Math.pow(2, otpDoc.resetCount); // waktu reset bertambah
  if (otpDoc.nextReset && now < otpDoc.nextReset.getTime()) {
    req.flash('error_msg', 'Tunggu ' + Math.ceil((otpDoc.nextReset.getTime() - now)/1000) + ' detik untuk reset OTP');
    return res.redirect('/forgot/verify?email=' + encodeURIComponent(email));
  }
  // Generate OTP baru
  const newOtp = ('' + Math.floor(100000 + Math.random() * 900000));
  otpDoc.otp = newOtp;
  otpDoc.expiresAt = new Date(now + 5 * 60 * 1000);
  otpDoc.attempts = 0;
  otpDoc.resetCount += 1;
  otpDoc.nextReset = new Date(now + waitTime);
  await otpDoc.save();
  // Kirim email OTP baru
  // ...
  req.flash('success_msg', 'Kode OTP baru telah dikirim');
  res.redirect('/forgot/verify?email=' + encodeURIComponent(email));
});

// POST: Set password baru
router.post('/reset-password', async (req, res) => {
  const { email, password } = req.body;
  // Cek session agar hanya user yang lolos OTP bisa reset password
  if (!req.session.resetPasswordEmail || req.session.resetPasswordEmail !== email) {
    req.flash('error_msg', 'Akses reset password tidak valid. Silakan ulangi proses.');
    return res.redirect('/forgot');
  }
  const user = await User.findOne({ email });
  if (!user) {
    req.flash('error_msg', 'User tidak ditemukan');
    return res.redirect('/forgot');
  }
  user.password = await bcrypt.hash(password, 10);
  await user.save();
  await Otp.deleteMany({ email });
  req.session.resetPasswordEmail = null; // hapus session
  req.flash('success_msg', 'Password berhasil direset, silakan login');
  res.redirect('/users/login');
});

module.exports = router;