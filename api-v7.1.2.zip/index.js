require("./settings"); 
__path = process.cwd()


const express       = require('express'),
      cors          = require('cors'),
      flash         = require('connect-flash'),
      rateLimit     = require("express-rate-limit"),
      passport      = require('passport'),
      expressLayout = require('express-ejs-layouts'),
      compression   = require('compression'),
      session       = require('express-session'),
      cookieParser  = require('cookie-parser'),
      MemoryStore   = require('memorystore')(session),
      secure        = require('ssl-express-www'),
      schedule      = require('node-schedule'),
      fs            = require('fs'),
      path          = require('path'),
      multer        = require('multer');
      axios = require('axios');
      FormData = require('form-data');
const PORT = process.env.PORT || 44556 || 5000 || 4000;
const app  = express();
const { color } = require('./lib/color.js');
const { startBot } = require('./lib/telegram');


const { isAuthenticated, isOwner } = require('./lib/auth');
const { connectMongoDb }  = require('./MongoDB/mongodb');
const { useLimit } = require('./MongoDB/function');
const { resetAllLimit, cekKey, limitAdd, getApikey } = require('./MongoDB/function');
const { countRequest }    = require('./lib/middleware');



connectMongoDb();
app.set('trust proxy', 1);
app.use(compression());

// === Rate Limit ===
const limiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 2000,
  message: 'Oops too many requests'
});
app.use(limiter);

app.set('view engine', 'ejs');
app.use(expressLayout);
app.use(express.static("assets"));
// Add static middleware for the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

app.enable('trust proxy');
app.set("json spaces", 2);
app.use(cors());
app.use(secure);

app.use(session({
  // Use a session secret from environment for security. If not set, a placeholder is used
  secret: process.env.SESSION_SECRET || 'change-me-please-set-SESSION_SECRET',
  resave: true,
  saveUninitialized: true,
  cookie: { maxAge: 86400000 },
  store: new MemoryStore({ checkPeriod: 86400000 })
}));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

app.use(passport.initialize());
app.use(passport.session());
// Middleware to persist background mode in session (must be after session/cookieParser)
app.use((req, res, next) => {
  if (req.query.bgmode) {
    req.session.bgmode = req.query.bgmode;
  }
  res.locals.bgmode = req.session.bgmode || 'default';
  next();
});
require('./lib/config')(passport);

app.use(flash());
app.use(function(req, res, next) {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg   = req.flash('error_msg');
  res.locals.error       = req.flash('error');
  res.locals.user        = req.user || null;
  next();
});

// ======= ROUTES VIEW =======
app.get('/', (req, res) => {
  res.render('home', { layout: 'home', bgmode: res.locals.bgmode });
});

app.get('/docs', isAuthenticated, async(req, res) => {
  // ambil key user login
  const getkey = await getApikey(req.user.id);
  const { apikey, username, limit, accountType } = getkey;
  res.render('index', { apikey, username, limit, accountType, layout: 'index', bgmode: res.locals.bgmode });
});

app.get('/shop', (req, res) => {
  res.render('shoplist', { layout: 'shoplist', bgmode: res.locals.bgmode });
});

// Dynamic pages
const pages = [
  'cecan','downloader','news','photooxy','search','nsfw',
  'random','anime','stiker','islam','game','other'
];

pages.forEach(page => {
  app.get(`/${page}`, isAuthenticated, async (req,res) => {
    const getkey = await getApikey(req.user.id);
    const { apikey, username } = getkey;
    res.render(page, { apikey, layout: page, bgmode: res.locals.bgmode });
  });
});

// ======= SETUP MULTER =======
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

// Buat subfolder untuk CDN local
const cdnDir = path.join(__dirname, 'uploads', 'cdn');
if (!fs.existsSync(cdnDir)) fs.mkdirSync(cdnDir, { recursive: true });

// fungsi random 6–7 karakter (huruf & angka)
function randomName(len = 7) {
  return Math.random().toString(36).substring(2, 2 + len);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, randomName(7) + ext);
  }
});

// filter + limit ukuran
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowed = ['.png','.jpg','.jpeg','.mp4'];
    allowed.includes(ext) ? cb(null,true) : cb(new Error('Only png, jpg, mp4 allowed'));
  },
  limits: { fileSize: 500 * 1024 * 1024 } // max 500MB
});



// ======= HALAMAN HTML UPLOAD =======
app.get('/upload-form', isAuthenticated, async(req,res)=>{
  const getkey = await getApikey(req.user.id);
  const { apikey } = getkey;
  res.render('upload', { apikey, layout: false });
});

app.post('/upload', upload.single('file'), async (req, res) => {
  try {
    const userApiKey = req.query.apikey || req.body.apikey;
    if (!userApiKey) {
      return res.status(400).json({ status:false, message:'apikey required' });
    }

    const keyInfo = await useLimit(userApiKey);
    if (!keyInfo) {
      return res.status(403).json({
        status:false,
        message:'Limit exceeded, tidak bisa upload lagi',
        limit_left: 0
      });
    }

    if (!req.file) {
      return res.status(400).json({ status:false, message:'No file uploaded' });
    }

    // pusat sistem upload
    const { uploadFile } = require('./lib/upload');
    const result = await uploadFile(req.file.path); // <– result.url

    return res.json({
  status: true,
  message: "Upload success",
  file_url: result.url,   // <-- pastikan ini "file_url"
  limit_left: keyInfo.limit
});


  } catch (err) {
    return res.status(500).json({ status:false, message: err.message });
  }
});

// static folder agar file bisa diakses publik
app.use('/uploads', express.static(uploadDir));

// router api lain tetap
// Endpoint update script (hanya untuk owner, simple auth via query secret)
app.post('/update-script', isAuthenticated, isOwner, async (req, res) => {
  // Optional extra secret check: if UPDATE_SECRET is set, require it as an additional factor
  const providedSecret = req.query.secret || req.body.secret;
  if (process.env.UPDATE_SECRET && providedSecret !== process.env.UPDATE_SECRET) {
    return res.status(403).json({ status: false, message: 'Forbidden' });
  }
  const { exec } = require('child_process');
  // Run git pull and restart, but only allow owner (checked by middleware). Don't leak raw stderr to clients.
  exec('git pull', { timeout: 10000 }, (err, stdout, stderr) => {
    if (err) {
      console.error('git pull failed:', err && err.message);
      return res.status(500).json({ status: false, message: 'Git pull failed' });
    }
    // Restart server (nodemon) if configured
    exec('npm run restart-server', { timeout: 10000 }, (err2, stdout2, stderr2) => {
      if (err2) {
        console.error('restart failed:', err2 && err2.message);
        return res.status(500).json({ status: false, message: 'Restart failed' });
      }
      res.json({ status: true, message: 'Script updated and server restarted' });
    });
  });
});

// ===== ROUTE MOUNT =====
// ========== ROUTES ==========
app.use('/api', countRequest, require('./routes/api'));
app.use('/main', require('./routes/main'));
app.use('/users', require('./routes/users'));
app.use('/profile', require('./routes/profile'));
app.use('/admin', require('./routes/admin'));
app.use('/forgot', require('./routes/forgot'));
app.use('/forgot', require('./routes/verifyOtp'));
app.use('/anime-admin', require('./routes/anime-admin'));



app.use(function (req, res) {
  const accept = (req.get('Accept') || '').toLowerCase();
  // If it's an API/JSON request, keep returning JSON
  if (req.xhr || req.path.startsWith('/api') || accept.includes('application/json')) {
    return res.status(404).json({ status: false, message: "Page not found" });
  }

  // Otherwise render friendly 404 page with custom image
  try {
    return res.status(404).render('404', {
      layout: false,
      imgUrl: '/img/403.png',
      title: '404 - Halaman Tidak Ditemukan',
      code: '404',
      message: 'Halaman tidak ditemukan atau Anda tidak memiliki izin untuk mengakses halaman ini.',
      btnText: 'Kembali ke Beranda',
      btnLink: '/'
    });
  } catch (e) {
    // Fallback to JSON if rendering fails
    return res.status(404).json({ status: false, message: "Page not found" });
  }
});
app.listen(PORT, "0.0.0.0", () => {
  console.log(color("Server running on port " + PORT, 'green'));
  startBot();
  schedule.scheduleJob('0 0 * * *', () => {
    resetAllLimit();
  });
});
module.exports = app;
