# Api NICKY (res-apikey) — Ringkasan & Panduan Instalasi

Project ini adalah server API (Express) untuk layanan apikey, downloader, generator gambar (PhotoOxy), koleksi gambar, upload, dan dashboard admin. Struktur utama dan file penting ada di repository — buka file-file terkait untuk referensi kode.

- Entry utama: [index.js](index.js)  
- Route API utama: [routes/api.js](routes/api.js)  
- Router upload (multipart): [routes/api-router.js](routes/api-router.js)  
- Modul upload eksternal: [`uploadFile`](lib/upload.js) ([lib/upload.js](lib/upload.js))  
- PhotoOxy helper: [`oxy`](lib/oxy.js) ([lib/oxy.js](lib/oxy.js))  
- Utility umum (buffer, random, dll): [lib/functions.js](lib/functions.js)  
- MongoDB connect: [`connectMongoDb`](MongoDB/mongodb.js) ([MongoDB/mongodb.js](MongoDB/mongodb.js))  
- MongoDB helper (apikey, limit): [`cekKey`](MongoDB/function.js), [`limitAdd`](MongoDB/function.js), [`useLimit`](MongoDB/function.js) ([MongoDB/function.js](MongoDB/function.js))  
- Konfigurasi global / default: [settings.js](settings.js)  
- Views (dashboard / admin): [views/](views/)  
- Package manifest: [package.json](package.json)

Ringkasan singkat fungsional:
- Sistem apikey + limit per-request diproses di [MongoDB/function.js](MongoDB/function.js) (fungsi: [`cekKey`](MongoDB/function.js), [`isLimit`](MongoDB/function.js), [`limitAdd`](MongoDB/function.js), [`useLimit`](MongoDB/function.js)).  
- Endpoint API utama berada di [routes/api.js](routes/api.js). Banyak endpoint mengecek apikey dan limit sebelum merespons.  
- Upload file di-handle oleh [routes/api-router.js](routes/api-router.js) dan di-forward ke layanan eksternal lewat [`uploadFile`](lib/upload.js).  
- Photooxy image generation menggunakan helper [`oxy`](lib/oxy.js) yang melakukan scraping/form submit ke photooxy.  

## Prasyarat
- Node.js (v16+ direkomendasikan)
- npm
- MongoDB (Atlas atau lokal)
- (Opsional) nodemon untuk development
- Dev container: Ubuntu 24.04.2 LTS (opsional, sesuai workspace)

## Instalasi
1. Clone repo ke server/development machine.
2. Install dependency:
```sh
npm install
```
3. Siapkan MongoDB dan dapatkan connection string.

## Konfigurasi
Project menggunakan kombinasi global di [settings.js](settings.js) dan beberapa env variable. Dua cara konfigurasi:

A. Edit langsung (tidak direkomendasikan untuk produksi)
- Buka [settings.js](settings.js) dan perbarui:
  - `global.MONGO_DB_URI` (URI MongoDB)
  - `global.your_email` dan `global.email_password` jika fitur email dipakai
  - `global.limitCount` untuk batas default apikey

B. Gunakan environment variables (lebih aman)
- Export/atur env sebelum menjalankan:
```sh
export PORT=44556
export MONGO_DB_URI="mongodb://<username>:<pass>@host:port/dbname"
export PHP_APIKEY="<opsional_php_apikey>"
# dll sesuai kebutuhan (lihat index.js / settings.js)
```
Catatan: Beberapa bagian (mis. `PHP_INTERNAL_APIKEY`) membaca dari `process.env.PHP_APIKEY` — lihat [index.js](index.js).

File yang perlu diperhatikan:
- [index.js](index.js) — startup server, middleware, konfigurasi multer, endpoint upload (lama & baru).
- [settings.js](settings.js) — konstanta global & pesan `loghandler`.
- [MongoDB/mongodb.js](MongoDB/mongodb.js) — [`connectMongoDb`](MongoDB/mongodb.js) untuk koneksi.
- [MongoDB/function.js](MongoDB/function.js) — logika apikey dan limit: [`limitAdd`](MongoDB/function.js), [`cekKey`](MongoDB/function.js), [`useLimit`](MongoDB/function.js).

## Menjalankan
- Development:
```sh
npm run dev   # jika ada skrip dev (nodemon)
# atau
node index.js
```
- Production:
  - Pastikan env sudah di-set (PORT, MONGO_DB_URI, dsb), lalu jalankan `node index.js` atau gunakan process manager (pm2/systemd).

## Endpoints penting & contoh
- Cek apikey: `/api/cekapikey?apikey=YOUR_KEY` — implementasi di [routes/api.js](routes/api.js).  
- Upload file (POST multipart): `/upload` — handler di [routes/api-router.js](routes/api-router.js) yang memanggil [`uploadFile`](lib/upload.js).  
- PhotoOxy generator: beberapa endpoint di [routes/api.js](routes/api.js) yang memakai [`oxy`](lib/oxy.js).  
- YouTube/TikTok/Facebook downloader: handler di [routes/api.js](routes/api.js) yang memakai btch-downloader.

## Tips debugging
- Lihat logs console saat startup; koneksi MongoDB dicetak oleh [`connectMongoDb`](MongoDB/mongodb.js).
- Periksa pesan error global di [settings.js](settings.js) (`loghandler`).
- Untuk masalah upload, periksa konsol dan respon dari [`uploadFile`](lib/upload.js) (domain c.termai.cc).

## Keamanan & rekomendasi
- Jangan commit kredensial nyata di [settings.js](settings.js) — gunakan env vars.  
- Batasi akses endpoint admin (`/users/*`, `/update-script`) hanya untuk owner.  
- Gunakan HTTPS / reverse proxy untuk produksi.

## Lokasi file yang sering dikunjungi
- [index.js](index.js) — konfigurasi server & middleware  
- [routes/api.js](routes/api.js) — semua endpoint API publik  
- [routes/api-router.js](routes/api-router.js) — upload endpoint multipart  
- [lib/oxy.js](lib/oxy.js) — PhotoOxy generator (`oxy`)  
- [lib/upload.js](lib/upload.js) — upload helper (`uploadFile`)  
- [MongoDB/mongodb.js](MongoDB/mongodb.js) — [`connectMongoDb`](MongoDB/mongodb.js)  
- [MongoDB/function.js](MongoDB/function.js) — fungsi apikey/limit (`cekKey`, `limitAdd`, `useLimit`)  
- [settings.js](settings.js) — pesan & global default

Jika perlu, saya bisa buatkan file contoh `.env.example` dan skrip npm untuk start/dev.