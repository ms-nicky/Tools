
/*INSTRUKSI SETUP UNTUK PEMULA:
1. Baca komentar di setiap pengaturan di bawah ini untuk memahami apa yang perlu diisi.
2. Ganti placeholder (seperti "ISI_NAMA_KAMU_DI_SINI") dengan informasi Anda sendiri.
3. Untuk keamanan, sebaiknya gunakan variabel environment (lihat bagian bawah file ini).
4. Jika Anda tidak yakin, tanyakan kepada penjual atau baca dokumentasi.
5. Setelah mengubah, restart aplikasi untuk menerapkan perubahan.
*/

/* ========== EDIT BAGIAN INI SAJA ========== */
const fs = require('fs');

// Nama pemilik / identitas (ganti dengan nama Anda)
global.creator = "NICKY";

// Token GitHub Fine-Grained PAT (prioritas lebih tinggi)
// Cara mendapatkannya: Pergi ke GitHub > Settings > Developer settings > Personal access tokens > Fine-grained tokens
// NOTE: Jangan commit token asli ke repository. Gunakan environment variable untuk keamanan.
global.GITHUB_PAT_TOKEN = "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";

// Repo database anime (format: username/reponame)
// Contoh: "pengguna/repo-anime". Buat repo di GitHub untuk menyimpan data anime.
global.GITHUB_REPO = "ms-nicky/anime-db";

// ========== TELEGRAM BOT ==========
// Token bot Telegram Anda. Dapatkan dari @BotFather di Telegram dengan perintah /newbot
global.TELEGRAM_BOT_TOKEN = "7809997656:AAHUuoH8U_-NaJwfNx5L8R_I9loSMnhcRHE";

// Debug mode untuk bot Telegram (ubah ke true jika ingin melihat log pesan)
global.TELEGRAM_BOT_DEBUG = false; // Ubah ke true jika mau lihat log pesan


// URI MongoDB (dapatkan dari MongoDB Atlas atau penyedia database lainnya)
global.MONGO_DB_URI = "mongodb+srv://Msxploiter:OV3LnrGmV1Bywlxp@database1.gvxak6b.mongodb.net/?retryWrites=true&w=majority&appName=Database1";

// Email (untuk verifikasi / login panel)
// Alamat email Anda yang akan digunakan untuk mengirim verifikasi
global.your_email = "nickystore604@gmail.com";

// Password email (gunakan Google App Password untuk Gmail)
// Cara mendapatkannya: Pergi ke Google Account > Security > App passwords
global.email_password = "tyldipvcnpifyxzw";

// API Limit default (per apikey) - jumlah maksimal penggunaan API per kunci
global.limitCount = 100;

// Port server API - port yang akan digunakan untuk menjalankan server
global.YUOR_PORT = 8000;

/* ========== JANGAN EDIT BAGIAN INI ========== */
// Fallback ke environment variables untuk keamanan (jangan ubah)
global.GITHUB_TOKEN = process.env.GITHUB_TOKEN || global.GITHUB_TOKEN;
global.GITHUB_PAT_TOKEN = process.env.GITHUB_PAT_TOKEN || global.GITHUB_PAT_TOKEN;
global.GITHUB_REPO  = process.env.GITHUB_REPO  || global.GITHUB_REPO;
global.IMGBB_API_KEY = process.env.IMGBB_API_KEY || global.IMGBB_API_KEY;
global.CLOUDINARY_CLOUD_NAME = process.env.CLOUDINARY_CLOUD_NAME || global.CLOUDINARY_CLOUD_NAME;
global.CLOUDINARY_UPLOAD_PRESET = process.env.CLOUDINARY_UPLOAD_PRESET || global.CLOUDINARY_UPLOAD_PRESET;

global.loghandler = {
	noapikey: {
		status: 403,
		message: 'Input parameter apikey',
		creator: `${creator}`,
		result: "error"
	},
	error: {
		status: 503,
		message: 'Service Unavailable, Sedang dalam perbaikan',
		creator: `${creator}`
	},
	apikey: {
		status: 403,
		message: 'Invalid apikey',
		creator: `${creator}`
	},
	noturl: {
		status: 403,
		message: 'Invalid url, masukkan parameter url yang benar',
		creator: `${creator}`,
	}
};

// Auto Reload config on save (jangan ubah)
let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(`Settings updated: '${__filename}'`);
	delete require.cache[file];
	require(file);
});
