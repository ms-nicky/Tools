/**
 * API Error Handler - Handle 401 errors dengan user-friendly modal
 * Intercept fetch & XMLHttpRequest untuk catch 401 responses
 */

(function() {
  window.APIErrorHandler = {
    
    init: function() {
      var self = this;
      
      // Intercept fetch
      var originalFetch = window.fetch;
      window.fetch = async function(url, options) {
        try {
          var response = await originalFetch.apply(this, arguments);
          if (response.status === 401) {
            try {
              var data = await response.clone().json();
              self.show401Modal(url, data);
            } catch (e) {
              self.show401Modal(url, { message: 'API Key diperlukan' });
            }
          }
          return response;
        } catch (error) {
          throw error;
        }
      };
    },

    show401Modal: function(url, errorData) {
      // Prevent duplicate modals
      if (document.querySelector('.api-error-modal-401')) return;
      
      var endpoint = this.extractEndpoint(url);
      var self = this;
      
      var html = '<div class="api-error-modal-401">' +
        '<div class="modal-overlay"></div>' +
        '<div class="modal-content">' +
          '<div class="modal-header">' +
            '<h2>🔐 API Key Diperlukan</h2>' +
            '<button class="close-btn">&times;</button>' +
          '</div>' +
          '<div class="modal-body">' +
            '<div class="error-box">' +
              '<i class="tim-icons icon-lock-circle"></i>' +
              '<p class="error-message">' + (errorData.message || 'API Key diperlukan untuk akses endpoint ini') + '</p>' +
            '</div>' +
            '<div class="endpoint-info">' +
              '<h3>Endpoint yang Anda Coba:</h3>' +
              '<code>' + (endpoint || url) + '</code>' +
            '</div>' +
            '<div class="steps">' +
              '<h3>Cara Mendapatkan API Key:</h3>' +
              '<ol>' +
                '<li><strong>Register/Login</strong><p>Kunjungi halaman login untuk membuat akun atau login</p></li>' +
                '<li><strong>Copy API Key</strong><p>Setelah login, copy API key dari dashboard Anda</p></li>' +
                '<li><strong>Gunakan API Key</strong><p>Tambahkan <code>?apikey=YOUR_KEY</code> ke endpoint URL</p></li>' +
              '</ol>' +
            '</div>' +
            '<div class="code-example">' +
              '<h3>Contoh Penggunaan:</h3>' +
              '<div class="code-box">' +
                '<strong>URL dengan API Key:</strong>' +
                '<code>' + endpoint + '?apikey=YOUR_API_KEY_HERE</code>' +
              '</div>' +
              '<div class="code-box">' +
                '<strong>JavaScript:</strong>' +
                '<pre>fetch("' + endpoint + '?apikey=YOUR_API_KEY")\n  .then(res =&gt; res.json())\n  .then(data =&gt; console.log(data))</pre>' +
              '</div>' +
              '<div class="code-box">' +
                '<strong>cURL:</strong>' +
                '<pre>curl "' + endpoint + '?apikey=YOUR_API_KEY"</pre>' +
              '</div>' +
            '</div>' +
            '<div class="action-buttons">' +
              '<button class="btn btn-primary btn-login"><i class="tim-icons icon-lock-circle"></i> Login / Register</button>' +
              '<button class="btn btn-secondary btn-close"><i class="tim-icons icon-simple-remove"></i> Tutup</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
      
      var modal = document.createElement('div');
      modal.innerHTML = html;
      var modalEl = modal.querySelector('.api-error-modal-401');
      
      // Add styles
      if (!document.getElementById('api-error-handler-styles')) {
        var style = document.createElement('style');
        style.id = 'api-error-handler-styles';
        style.textContent = this.getStyles();
        document.head.appendChild(style);
      }
      
      document.body.appendChild(modalEl);
      
      // Event handlers
      var closeBtn = modalEl.querySelector('.close-btn');
      var loginBtn = modalEl.querySelector('.btn-login');
      var closeModalBtn = modalEl.querySelector('.btn-close');
      var overlay = modalEl.querySelector('.modal-overlay');
      
      var removeModal = function() {
        modalEl.style.animation = 'slideOut 0.3s ease';
        setTimeout(function() { modalEl.remove(); }, 300);
      };
      
      if (closeBtn) closeBtn.addEventListener('click', removeModal);
      if (closeModalBtn) closeModalBtn.addEventListener('click', removeModal);
      if (overlay) overlay.addEventListener('click', removeModal);
      
      if (loginBtn) {
        loginBtn.addEventListener('click', function() {
          if (errorData.login_url) {
            window.location.href = errorData.login_url;
          } else {
            window.location.href = '/users/login';
          }
        });
      }
      
      // Keyboard close
      var keyListener = function(e) {
        if (e.key === 'Escape') {
          removeModal();
          document.removeEventListener('keydown', keyListener);
        }
      };
      document.addEventListener('keydown', keyListener);
    },

    extractEndpoint: function(url) {
      try {
        var urlObj = new URL(url);
        return urlObj.pathname + (urlObj.search ? urlObj.search : '');
      } catch (e) {
        return url;
      }
    },

    getStyles: function() {
      return '.api-error-modal-401{position:fixed;top:0;left:0;right:0;bottom:0;z-index:99999;display:flex;align-items:center;justify-content:center;animation:slideIn401 0.3s ease}@keyframes slideIn401{from{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}@keyframes slideOut401{from{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-20px)}}.api-error-modal-401 .modal-overlay{position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.7);cursor:pointer}.api-error-modal-401 .modal-content{position:relative;background:#27293d;border:1px solid #404456;border-radius:12px;max-width:600px;max-height:85vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,0.4)}.api-error-modal-401 .modal-header{display:flex;justify-content:space-between;align-items:center;padding:1.5rem;border-bottom:2px solid #667eea;background:linear-gradient(135deg,rgba(102,126,234,0.1),transparent);position:sticky;top:0}.api-error-modal-401 .modal-header h2{margin:0;color:#fff;font-size:1.3em;display:flex;align-items:center;gap:0.5rem}.api-error-modal-401 .close-btn{background:0;border:0;color:#aaa;font-size:1.8em;cursor:pointer;transition:color 0.2s}.api-error-modal-401 .close-btn:hover{color:#fff}.api-error-modal-401 .modal-body{padding:2rem}.api-error-modal-401 .error-box{background:rgba(220,53,69,0.1);border:1px solid rgba(220,53,69,0.3);border-radius:8px;padding:1.5rem;text-align:center;margin-bottom:1.5rem}.api-error-modal-401 .error-box i{font-size:2.5em;color:#dc3545;display:block;margin-bottom:0.5rem}.api-error-modal-401 .error-message{color:#dc3545;margin:0;font-weight:600;font-size:1.1em}.api-error-modal-401 .endpoint-info{background:#1a1c2e;border:1px solid #404456;border-radius:8px;padding:1rem;margin-bottom:1.5rem}.api-error-modal-401 .endpoint-info h3{color:#667eea;margin:0 0 0.8rem 0;font-size:0.9em;text-transform:uppercase;letter-spacing:0.5px}.api-error-modal-401 code{background:#0f1419;color:#10b981;padding:0.8rem;border-radius:6px;display:block;font-family:"Courier New",monospace;font-size:0.9em;overflow-x:auto;word-break:break-all}.api-error-modal-401 .steps{margin-bottom:1.5rem}.api-error-modal-401 .steps h3{color:#667eea;margin:0 0 1rem 0;font-size:1em}.api-error-modal-401 .steps ol{list-style:none;padding:0;margin:0;counter-reset:step-counter}.api-error-modal-401 .steps li{counter-increment:step-counter;margin-bottom:1rem;padding-left:3rem;position:relative}.api-error-modal-401 .steps li::before{content:counter(step-counter);position:absolute;left:0;top:0;background:#667eea;color:#fff;width:2rem;height:2rem;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:0.9em}.api-error-modal-401 .steps strong{color:#fff;display:block;margin-bottom:0.3rem}.api-error-modal-401 .steps p{color:#aaa;margin:0;font-size:0.95em;line-height:1.5}.api-error-modal-401 .code-example{margin-bottom:1.5rem}.api-error-modal-401 .code-example h3{color:#667eea;margin:0 0 1rem 0;font-size:1em}.api-error-modal-401 .code-box{background:#1a1c2e;border:1px solid #404456;border-radius:8px;padding:1rem;margin-bottom:0.8rem}.api-error-modal-401 .code-box strong{color:#aaa;font-size:0.9em;display:block;margin-bottom:0.5rem;text-transform:uppercase;letter-spacing:0.3px}.api-error-modal-401 pre{margin:0;overflow-x:auto}.api-error-modal-401 pre code{background:0;color:#10b981;padding:0;display:block;font-size:0.85em;line-height:1.4}.api-error-modal-401 .action-buttons{display:flex;gap:1rem;margin-top:2rem;padding-top:1.5rem;border-top:1px solid #404456}.api-error-modal-401 .btn{flex:1;padding:0.8rem 1rem;border:0;border-radius:6px;font-weight:600;cursor:pointer;font-size:0.95em;display:flex;align-items:center;justify-content:center;gap:0.5rem;transition:all 0.2s}.api-error-modal-401 .btn-primary{background:#667eea;color:#fff}.api-error-modal-401 .btn-primary:hover{background:#764ba2;transform:translateY(-2px);box-shadow:0 4px 12px rgba(102,126,234,0.4)}.api-error-modal-401 .btn-secondary{background:#404456;color:#aaa}.api-error-modal-401 .btn-secondary:hover{background:#4a5470;color:#fff}@media (max-width:600px){.api-error-modal-401 .modal-content{max-width:90vw;max-height:90vh}.api-error-modal-401 .modal-body{padding:1.5rem}.api-error-modal-401 .action-buttons{flex-direction:column}}';
    }
  };

  // Auto-init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      window.APIErrorHandler.init();
    });
  } else {
    window.APIErrorHandler.init();
  }
})();
