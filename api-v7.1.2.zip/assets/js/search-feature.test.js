/**
 * Search Feature - Test Cases
 * Unit tests untuk search functionality
 */

// Test data
const TEST_CASES = [
  {
    name: "Search by feature name",
    query: "cecan",
    expectedResults: ["Cecan API"],
    description: "Should find fitur by exact name"
  },
  {
    name: "Search by partial name",
    query: "down",
    expectedResults: ["Download API"],
    description: "Should find fitur by partial match"
  },
  {
    name: "Search by category",
    query: "api",
    expectedResults: ["Cecan API", "Download API", "News API"], // Many results
    description: "Should find fitur by category"
  },
  {
    name: "Search by path",
    query: "/docs",
    expectedResults: ["Dashboard"],
    description: "Should find fitur by path"
  },
  {
    name: "Case insensitive search",
    query: "CECAN",
    expectedResults: ["Cecan API"],
    description: "Should be case insensitive"
  },
  {
    name: "Empty search",
    query: "",
    expectedResults: [],
    description: "Should return empty array"
  },
  {
    name: "Search with spaces",
    query: "random img",
    expectedResults: ["Random Image"],
    description: "Should find by description with spaces"
  }
];

// Manual test functions
function testSearch() {
  console.log("🧪 Starting Search Feature Tests...\n");
  
  let passed = 0;
  let failed = 0;

  // Get SearchFeature from window
  if (typeof window.SearchFeature === 'undefined') {
    console.error("❌ SearchFeature not found!");
    return;
  }

  const features = window.SearchFeature.features;
  console.log(`📦 Loaded ${features.length} features\n`);

  TEST_CASES.forEach((testCase, idx) => {
    const query = testCase.query.toLowerCase().trim();
    const filtered = features.filter(f => 
      f.name.toLowerCase().includes(query) || 
      f.desc.toLowerCase().includes(query) ||
      f.path.toLowerCase().includes(query) ||
      f.category.toLowerCase().includes(query)
    );

    const success = testCase.expectedResults.length === 0 
      ? filtered.length === 0
      : testCase.expectedResults.some(exp => 
          filtered.some(f => f.name.includes(exp))
        );

    if (success) {
      console.log(`✅ Test ${idx + 1}: ${testCase.name}`);
      console.log(`   Query: "${testCase.query}"`);
      console.log(`   Results: ${filtered.map(f => f.name).join(", ") || "none"}`);
      passed++;
    } else {
      console.log(`❌ Test ${idx + 1}: ${testCase.name}`);
      console.log(`   Query: "${testCase.query}"`);
      console.log(`   Expected: ${testCase.expectedResults.join(", ") || "none"}`);
      console.log(`   Got: ${filtered.map(f => f.name).join(", ") || "none"}`);
      failed++;
    }
    console.log();
  });

  // Summary
  console.log("📊 Test Summary");
  console.log(`✅ Passed: ${passed}`);
  console.log(`❌ Failed: ${failed}`);
  console.log(`📈 Success Rate: ${((passed / (passed + failed)) * 100).toFixed(1)}%`);
}

// Feature validation
function validateFeatures() {
  console.log("\n🔍 Validating Features...\n");

  const features = window.SearchFeature.features;
  let issues = 0;

  features.forEach((f, idx) => {
    const checks = [
      { prop: 'name', type: 'string', required: true },
      { prop: 'path', type: 'string', required: true },
      { prop: 'icon', type: 'string', required: true },
      { prop: 'category', type: 'string', required: true },
      { prop: 'desc', type: 'string', required: true }
    ];

    checks.forEach(check => {
      const value = f[check.prop];
      if (check.required && (!value || typeof value !== check.type)) {
        console.error(`❌ Feature ${idx}: Missing or invalid ${check.prop}`);
        console.error(`   Value: ${value}, Expected type: ${check.type}`);
        issues++;
      }
    });
  });

  if (issues === 0) {
    console.log(`✅ All ${features.length} features are valid!`);
  } else {
    console.log(`\n⚠️  Found ${issues} issues`);
  }
}

// Performance test
function testPerformance() {
  console.log("\n⚡ Performance Test\n");

  const features = window.SearchFeature.features;
  const queries = ["cecan", "download", "api", "random", ""];

  queries.forEach(query => {
    const startTime = performance.now();
    
    const filtered = features.filter(f => 
      f.name.toLowerCase().includes(query) || 
      f.desc.toLowerCase().includes(query) ||
      f.path.toLowerCase().includes(query) ||
      f.category.toLowerCase().includes(query)
    );
    
    const endTime = performance.now();
    const duration = endTime - startTime;

    console.log(`Query: "${query || '(empty)'}"`);
    console.log(`Results: ${filtered.length}`);
    console.log(`Time: ${duration.toFixed(2)}ms`);
    console.log(duration > 10 ? `⚠️  Slow` : `✅ Fast`);
    console.log();
  });
}

// DOM testing
function testDOM() {
  console.log("\n🎨 DOM Test\n");

  const checks = [
    { element: '#searchModal', name: 'Search Modal' },
    { element: '#searchInput', name: 'Search Input' },
    { element: '#searchResults', name: 'Search Results Container' },
    { element: '#search-button', name: 'Search Button' }
  ];

  checks.forEach(check => {
    const element = document.querySelector(check.element);
    if (element) {
      console.log(`✅ ${check.name} found`);
      console.log(`   Selector: ${check.element}`);
      console.log(`   Tag: ${element.tagName}`);
    } else {
      console.log(`❌ ${check.name} not found`);
      console.log(`   Selector: ${check.element}`);
    }
  });
}

// Run all tests
function runAllTests() {
  testSearch();
  validateFeatures();
  testPerformance();
  testDOM();
  
  console.log("\n✅ All tests completed!");
  console.log("Run each test individually:");
  console.log("- testSearch()");
  console.log("- validateFeatures()");
  console.log("- testPerformance()");
  console.log("- testDOM()");
}

// Export for console
window.SearchTests = {
  runAll: runAllTests,
  testSearch: testSearch,
  validateFeatures: validateFeatures,
  testPerformance: testPerformance,
  testDOM: testDOM
};

console.log("🧪 Search Feature Tests loaded!");
console.log("Run 'SearchTests.runAll()' to start all tests");
