/**
 * Global Search Feature
 * Fitur pencarian global untuk semua halaman
 */

(function() {
  // Data fitur API yang lengkap
  const API_FEATURES = [
    // Main Pages
    { name: 'Dashboard', path: '/docs', icon: 'icon-chart-pie-36', category: 'Main', desc: 'Dashboard utama dengan statistik' },
    { name: 'Home', path: '/', icon: 'icon-home', category: 'Main', desc: 'Halaman beranda' },
    { name: 'Profile', path: '/profile', icon: 'icon-user', category: 'Main', desc: 'Profil pengguna & pengaturan' },
    { name: 'Shop', path: '/shop', icon: 'icon-cart', category: 'Main', desc: 'Toko API premium & paket' },
    
    // Main API Categories
    { name: 'Cecan API', path: '/cecan', icon: 'icon-send', category: 'API', desc: 'Random gambar cecan cantik' },
    { name: 'Download API', path: '/downloader', icon: 'icon-cloud-download-93', category: 'API', desc: 'Download video dari TikTok, Instagram, YouTube, dll' },
    { name: 'News API', path: '/news', icon: 'icon-paper', category: 'API', desc: 'Berita terkini dari berbagai sumber' },
    { name: 'PhotoOxy API', path: '/photooxy', icon: 'icon-image-02', category: 'API', desc: 'Generate foto dengan berbagai effect' },
    { name: 'Random Image', path: '/search', icon: 'icon-refresh-01', category: 'API', desc: 'Gambar random dari berbagai kategori' },
    { name: 'NSFW API', path: '/nsfw', icon: 'icon-heart-2', category: 'API', desc: 'Konten NSFW random (18+)' },
    { name: 'Anime API', path: '/anime', icon: 'icon-heart-2', category: 'API', desc: 'Karakter anime & wallpaper' },
    { name: 'Random Stiker', path: '/stiker', icon: 'icon-image-02', category: 'API', desc: 'Stiker WhatsApp random' },
    { name: 'Islamic API', path: '/islam', icon: 'icon-istanbul', category: 'API', desc: 'Konten islami & hadis' },
    { name: 'Games API', path: '/game', icon: 'icon-puzzle-10', category: 'API', desc: 'Endpoint game & mini games' },
    { name: 'Others API', path: '/other', icon: 'icon-globe-2', category: 'API', desc: 'API lainnya yang tidak dikategorikan' },
    
    // Cecan Sub-endpoints
    { name: 'Cecan China', path: '/api/cecan/china', icon: 'icon-send', category: 'Cecan', desc: 'Gambar cecan dari China' },
    { name: 'Cecan Vietnam', path: '/api/cecan/vietnam', icon: 'icon-send', category: 'Cecan', desc: 'Gambar cecan dari Vietnam' },
    { name: 'Cecan Thailand', path: '/api/cecan/thailand', icon: 'icon-send', category: 'Cecan', desc: 'Gambar cecan dari Thailand' },
    { name: 'Cecan Indonesia', path: '/api/cecan/indonesia', icon: 'icon-send', category: 'Cecan', desc: 'Gambar cecan dari Indonesia' },
    { name: 'Cecan Korea', path: '/api/cecan/korea', icon: 'icon-send', category: 'Cecan', desc: 'Gambar cecan dari Korea' },
    { name: 'Cecan Japan', path: '/api/cecan/japan', icon: 'icon-send', category: 'Cecan', desc: 'Gambar cecan dari Jepang' },
    { name: 'Cecan Malaysia', path: '/api/cecan/malaysia', icon: 'icon-send', category: 'Cecan', desc: 'Gambar cecan dari Malaysia' },
    
    // Search Sub-endpoints (with parameters)
    { name: 'Google Image Search', path: '/api/search/google-image', icon: 'icon-refresh-01', category: 'Search', desc: 'Cari gambar dari Google', params: { query: { name: 'Keyword', placeholder: 'Contoh: anime girl' } } },
    { name: 'Wallpaper Search', path: '/api/search/wallpaper', icon: 'icon-refresh-01', category: 'Search', desc: 'Cari wallpaper', params: { query: { name: 'Keyword', placeholder: 'Contoh: landscape' } } },
    { name: 'Pinterest Search', path: '/api/search/pinterest', icon: 'icon-refresh-01', category: 'Search', desc: 'Cari dari Pinterest', params: { query: { name: 'Keyword', placeholder: 'Contoh: fashion' } } },
    
    // NSFW Sub-endpoints
    { name: 'NSFW Ass', path: '/api/nsfw/ass', icon: 'icon-heart-2', category: 'NSFW', desc: 'NSFW konten (18+)' },
    { name: 'NSFW Ahegao', path: '/api/nsfw/ahegao', icon: 'icon-heart-2', category: 'NSFW', desc: 'NSFW konten (18+)' },
    { name: 'NSFW BDSM', path: '/api/nsfw/bdsm', icon: 'icon-heart-2', category: 'NSFW', desc: 'NSFW konten (18+)' },
    { name: 'NSFW Blowjob', path: '/api/nsfw/blowjob', icon: 'icon-heart-2', category: 'NSFW', desc: 'NSFW konten (18+)' },
    { name: 'NSFW Cuckold', path: '/api/nsfw/cuckold', icon: 'icon-heart-2', category: 'NSFW', desc: 'NSFW konten (18+)' },
    
    // Random Sub-endpoints
    { name: 'Random Cosplay', path: '/api/random/cosplay', icon: 'icon-image-02', category: 'Random', desc: 'Foto cosplay random' },
    { name: 'Random Kucing', path: '/api/random/kucing', icon: 'icon-image-02', category: 'Random', desc: 'Foto kucing random' },
    { name: 'Random Ryujin', path: '/api/random/ryujin', icon: 'icon-image-02', category: 'Random', desc: 'Foto Ryujin random' },
    { name: 'Random PUBG', path: '/api/random/pubg', icon: 'icon-image-02', category: 'Random', desc: 'Foto PUBG random' },
    { name: 'Random Profile', path: '/api/random/profile', icon: 'icon-image-02', category: 'Random', desc: 'Profil random' },
    { name: 'Random Wallpaper', path: '/api/random/wallml', icon: 'icon-image-02', category: 'Random', desc: 'Wallpaper ML random' },
    { name: 'Random Car', path: '/api/random/car', icon: 'icon-image-02', category: 'Random', desc: 'Foto mobil random' },
    
    // Stiker Sub-endpoints
    { name: 'Stiker Patrick', path: '/api/stiker/patrik', icon: 'icon-image-02', category: 'Stiker', desc: 'Stiker Patrick SpongeBob' },
    { name: 'Stiker Teman SpongeBob', path: '/api/stiker/teman-sponsbob', icon: 'icon-image-02', category: 'Stiker', desc: 'Stiker teman SpongeBob' },
    { name: 'Stiker Meme WA', path: '/api/stiker/meme-wa', icon: 'icon-image-02', category: 'Stiker', desc: 'Stiker meme WhatsApp' },
    { name: 'Stiker SpongeBob', path: '/api/stiker/sponsbob', icon: 'icon-image-02', category: 'Stiker', desc: 'Stiker SpongeBob' },
    { name: 'Stiker Brat', path: '/api/stiker/brat', icon: 'icon-image-02', category: 'Stiker', desc: 'Stiker Brat' },
    
    // Anime Sub-endpoints
    { name: 'Anime Waifu', path: '/api/anime/waifu', icon: 'icon-heart-2', category: 'Anime', desc: 'Karakter waifu anime' },
    { name: 'Anime Loli', path: '/api/anime/loli', icon: 'icon-heart-2', category: 'Anime', desc: 'Karakter loli anime' },
    { name: 'Anime Neko', path: '/api/anime/neko', icon: 'icon-heart-2', category: 'Anime', desc: 'Karakter neko anime' },
    { name: 'Anime Husbu', path: '/api/anime/husbu', icon: 'icon-heart-2', category: 'Anime', desc: 'Karakter husbu anime' },
    { name: 'Anime Shota', path: '/api/anime/shota', icon: 'icon-heart-2', category: 'Anime', desc: 'Karakter shota anime' },
    { name: 'Anime General', path: '/api/anime/anime', icon: 'icon-heart-2', category: 'Anime', desc: 'Anime umum' },
    { name: 'Anime Wallpaper', path: '/api/anime/wallpaper-anime', icon: 'icon-heart-2', category: 'Anime', desc: 'Wallpaper anime' },
    { name: 'Elaina', path: '/api/anime/elaina', icon: 'icon-heart-2', category: 'Anime', desc: 'Karakter Elaina dari Majo no Tabitabi' },
    { name: 'Blue Archive', path: '/api/anime/blue-archive', icon: 'icon-heart-2', category: 'Anime', desc: 'Karakter Blue Archive' },
    { name: 'PP Cowo', path: '/api/anime/pp_cowo', icon: 'icon-heart-2', category: 'Anime', desc: 'Profile picture laki-laki anime' },
    { name: 'PP Cewe', path: '/api/anime/pp_cewe', icon: 'icon-heart-2', category: 'Anime', desc: 'Profile picture perempuan anime' },
    
    // Other Sub-endpoints
    { name: 'GitHub Stalk', path: '/api/other/github-stalk', icon: 'icon-globe-2', category: 'Other', desc: 'Stalk profil GitHub', params: { username: { name: 'GitHub Username', placeholder: 'Contoh: torvalds' } } },
    { name: 'Hilih', path: '/api/other/hilih', icon: 'icon-globe-2', category: 'Other', desc: 'Hilih endpoint' },
    { name: 'Kode Pos', path: '/api/other/kodepos', icon: 'icon-globe-2', category: 'Other', desc: 'Cari kode pos', params: { kodepos: { name: 'Kode Pos', placeholder: 'Contoh: 12345' } } },
    { name: 'COVID World', path: '/api/other/covid-world', icon: 'icon-globe-2', category: 'Other', desc: 'Data COVID-19 dunia' },
    { name: 'KBBI', path: '/api/other/kbbi', icon: 'icon-globe-2', category: 'Other', desc: 'Cari di Kamus Besar Bahasa Indonesia', params: { query: { name: 'Kata Kunci', placeholder: 'Contoh: makan' } } },
    
    // Download endpoints (with parameters)
    { name: 'TikTok Downloader', path: '/api/download/tiktok', icon: 'icon-cloud-download-93', category: 'Download', desc: 'Download video dari TikTok', params: { url: { name: 'TikTok URL', placeholder: 'https://www.tiktok.com/...', type: 'url' } } },
    { name: 'Instagram Downloader', path: '/api/download/instagram', icon: 'icon-cloud-download-93', category: 'Download', desc: 'Download dari Instagram', params: { url: { name: 'Instagram URL', placeholder: 'https://www.instagram.com/...', type: 'url' } } },
    { name: 'YouTube Downloader', path: '/api/download/youtube', icon: 'icon-cloud-download-93', category: 'Download', desc: 'Download video dari YouTube', params: { url: { name: 'YouTube URL', placeholder: 'https://www.youtube.com/...', type: 'url' } } },
    { name: 'Facebook Downloader', path: '/api/download/facebook', icon: 'icon-cloud-download-93', category: 'Download', desc: 'Download dari Facebook', params: { url: { name: 'Facebook URL', placeholder: 'https://www.facebook.com/...', type: 'url' } } },
    { name: 'Twitter Downloader', path: '/api/download/twitter', icon: 'icon-cloud-download-93', category: 'Download', desc: 'Download dari Twitter', params: { url: { name: 'Twitter URL', placeholder: 'https://twitter.com/...', type: 'url' } } },
    
    // Tools
    { name: 'Upload Post', path: '/upload-form', icon: 'icon-send', category: 'Tools', desc: 'Upload file ke CDN untuk dibagikan' },
    { name: 'Check API Key', path: '/docs', icon: 'icon-key-25', category: 'Tools', desc: 'Cek statistik API key Anda' },
  ];

  window.SearchFeature = {
    features: API_FEATURES,
    
    /**
     * Initialize search feature
     */
    init: function() {
      this.setupSearchModal();
      this.setupKeyboardShortcuts();
      this.setupSearchInput();
    },

    /**
     * Setup search modal
     */
    setupSearchModal: function() {
      // Create modal if not exists
      if (!document.getElementById('searchModal')) {
        this.createSearchModal();
      }

      const searchModal = document.getElementById('searchModal');
      if (searchModal) {
        searchModal.addEventListener('show.bs.modal', () => {
          const input = document.getElementById('searchInput');
          if (input) {
            setTimeout(() => input.focus(), 100);
            input.value = '';
            this.renderResults('');
          }
        });
      }
    },

    /**
     * Create search modal HTML
     */
    createSearchModal: function() {
      const modalHTML = `
        <div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content" style="background: #27293d; border: 1px solid #404456; border-radius: 12px;">
              <div class="modal-header" style="border-bottom: 1px solid #404456; padding: 1.5rem;">
                <div style="width: 100%; display: flex; align-items: center; gap: 10px;">
                  <i class="tim-icons icon-zoom-split" style="color: #667eea; font-size: 1.2em;"></i>
                  <input type="text" class="form-control" id="searchInput" placeholder="Cari fitur API... (Ctrl+K)" style="background: #1a1c2e; border: 1px solid #404456; color: #fff; font-size: 1.1em; padding: 0.75rem 1rem;">
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: #fff; opacity: 0.7;">
                  <i class="tim-icons icon-simple-remove"></i>
                </button>
              </div>
              <div class="modal-body" style="max-height: 500px; overflow-y: auto; padding: 0;">
                <div id="searchResults" style="padding: 1rem;">
                  <div style="color: #888; text-align: center; padding: 2rem;">
                    <i class="tim-icons icon-zoom-split" style="font-size: 2em; margin-bottom: 1rem; display: block;"></i>
                    Mulai mengetik untuk mencari fitur...
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
      document.body.insertAdjacentHTML('beforeend', modalHTML);
    },

    /**
     * Setup search input event
     */
    setupSearchInput: function() {
      const searchInput = document.getElementById('searchInput');
      if (searchInput) {
        searchInput.addEventListener('input', (e) => {
          const query = e.target.value.toLowerCase().trim();
          this.renderResults(query);
        });

        // Arrow keys navigation
        searchInput.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            const items = document.querySelectorAll('.search-result-item');
            if (items.length > 0) items[0].focus();
          }
        });
      }
    },

    /**
     * Render search results
     */
    renderResults: function(query) {
      const searchResults = document.getElementById('searchResults');
      if (!searchResults) return;

      if (!query) {
        searchResults.innerHTML = `
          <div style="color: #888; text-align: center; padding: 2rem;">
            <i class="tim-icons icon-zoom-split" style="font-size: 2em; margin-bottom: 1rem; display: block;"></i>
            Mulai mengetik untuk mencari fitur...
          </div>
        `;
        return;
      }

      const filtered = API_FEATURES.filter(f => 
        f.name.toLowerCase().includes(query) || 
        f.desc.toLowerCase().includes(query) ||
        f.path.toLowerCase().includes(query) ||
        f.category.toLowerCase().includes(query)
      );

      if (filtered.length === 0) {
        searchResults.innerHTML = `
          <div style="color: #888; text-align: center; padding: 2rem;">
            <i class="tim-icons icon-zoom-split" style="font-size: 2em; opacity: 0.5; margin-bottom: 1rem; display: block;"></i>
            Tidak ada fitur yang cocok dengan "<strong>${this.escapeHtml(query)}</strong>"
          </div>
        `;
        return;
      }

      // Group by category
      const grouped = {};
      filtered.forEach(f => {
        if (!grouped[f.category]) grouped[f.category] = [];
        grouped[f.category].push(f);
      });

      let html = '';
      const self = this;
      Object.entries(grouped).forEach(([category, items]) => {
        html += `<div style="padding: 0.5rem 0;"><small style="color: #666; padding: 0.5rem 1rem; text-transform: uppercase; font-weight: 600;">${category}</small>`;
        items.forEach((f, idx) => {
          const endpointPath = f.path;
          html += `
            <a href="javascript:void(0)" class="search-result-item" onclick="SearchFeature.openEndpoint('${endpointPath}'); setTimeout(() => $('#searchModal').modal('hide'), 100)" style="display: flex; align-items: center; padding: 1rem; border-bottom: 1px solid #404456; text-decoration: none; color: #fff; transition: background 0.2s; cursor: pointer;">
              <i class="tim-icons ${f.icon}" style="font-size: 1.5em; color: #667eea; margin-right: 1rem; min-width: 30px;"></i>
              <div style="flex: 1; min-width: 0;">
                <div style="font-weight: 600; color: #fff; font-size: 1em;">${self.highlightQuery(f.name, query)}</div>
                <div style="color: #aaa; font-size: 0.9em;">${self.highlightQuery(f.desc, query)}</div>
                <div style="color: #666; font-size: 0.8em; margin-top: 0.3rem;">→ ${endpointPath}</div>
              </div>
              <i class="tim-icons icon-minimal-right" style="color: #667eea; font-size: 1.2em;"></i>
            </a>
          `;
        });
        html += '</div>';
      });

      searchResults.innerHTML = html;

      // Add hover effects
      const items = searchResults.querySelectorAll('.search-result-item');
      items.forEach(item => {
        item.addEventListener('mouseover', () => {
          item.style.background = 'rgba(102, 126, 234, 0.1)';
        });
        item.addEventListener('mouseout', () => {
          item.style.background = 'transparent';
        });
        item.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            item.nextElementSibling?.focus();
          } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            item.previousElementSibling?.focus();
          } else if (e.key === 'Enter') {
            item.click();
          }
        });
      });
    },

    /**
     * Highlight query in text
     */
    highlightQuery: function(text, query) {
      if (!query) return this.escapeHtml(text);
      
      const regex = new RegExp(`(${query})`, 'gi');
      return this.escapeHtml(text).replace(regex, '<mark style="background: rgba(102, 126, 234, 0.3); color: #fff; border-radius: 2px; padding: 0 2px;">$1</mark>');
    },

    /**
     * Escape HTML to prevent XSS
     */
    escapeHtml: function(text) {
      const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      };
      return text.replace(/[&<>"']/g, m => map[m]);
    },

    /**
     * Setup keyboard shortcuts
     */
    setupKeyboardShortcuts: function() {
      document.addEventListener('keydown', (e) => {
        // Ctrl+K atau Cmd+K untuk buka search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
          e.preventDefault();
          if (typeof $ !== 'undefined') {
            $('#searchModal').modal('show');
          }
        }
      });
    },

    /**
     * Get API key dari berbagai sumber
     */
    getAPIKey: function() {
      // Coba dari localStorage dengan berbagai key names
      let apiKey = localStorage.getItem('apikey') || localStorage.getItem('userApiKey');
      if (apiKey && apiKey.trim()) return apiKey.trim();
      
      // Coba dari DOM element dengan id atau data attribute
      const apiKeyElementById = document.getElementById('apikey');
      if (apiKeyElementById) {
        let keyFromId = apiKeyElementById.getAttribute('data-apikey') || apiKeyElementById.textContent;
        if (keyFromId && keyFromId.trim()) return keyFromId.trim();
      }
      
      // Coba dari element dengan data-apikey attribute
      const apiKeyElement = document.querySelector('[data-apikey]');
      if (apiKeyElement) {
        let keyFromAttr = apiKeyElement.getAttribute('data-apikey');
        if (keyFromAttr && keyFromAttr.trim()) return keyFromAttr.trim();
      }
      
      // Coba dari input field di form
      const inputField = document.querySelector('input[name="apikey"], input[id="apikey"]');
      if (inputField && inputField.value && inputField.value.trim()) return inputField.value.trim();
      
      // Coba dari page content dengan better regex
      const pageText = document.body.textContent;
      const match = pageText.match(/apikey[:\s]*([a-f0-9\-]{32,})/i);
      if (match && match[1]) return match[1].trim();
      
      return null;
    },

    /**
     * Open endpoint with API key & dynamic parameters
     */
    openEndpoint: function(path) {
      // Get API key dari berbagai sumber
      let apiKey = this.getAPIKey();
      
      // If no API key found, show helpful message
      if (!apiKey) {
        alert('❌ API Key tidak ditemukan!\n\nSilakan:\n1. Login ke dashboard\n2. Copy API key Anda\n3. Simpan di browser atau akses dari dashboard');
        return;
      }
      
      // Find the feature object to check if it has parameters
      const feature = API_FEATURES.find(f => f.path === path);
      
      // If feature has parameters, show input form
      if (feature && feature.params && Object.keys(feature.params).length > 0) {
        this.showParameterModal(path, apiKey, feature);
        return;
      }
      
      // Has API key, open endpoint in new tab
      const urlWithKey = path + (path.includes('?') ? '&' : '?') + 'apikey=' + encodeURIComponent(apiKey);
      window.open(urlWithKey, '_blank');
    },

    /**
     * Show modal to input required parameters
     */
    showParameterModal: function(path, apiKey, feature) {
      const params = feature.params || {};
      const paramKeys = Object.keys(params);
      
      if (paramKeys.length === 0) return;
      
      // Build modal content
      let modalContent = `Parameter untuk: ${feature.name}\n\n`;
      const formData = {};
      
      // Create input form for parameters
      const container = document.createElement('div');
      container.style.cssText = 'background:#27293d; border:1px solid #404456; border-radius:8px; padding:20px; color:#fff; font-family:Poppins,sans-serif;';
      
      const title = document.createElement('h4');
      title.textContent = `📝 ${feature.name}`;
      title.style.cssText = 'margin:0 0 15px 0; color:#667eea; font-size:1.1em;';
      container.appendChild(title);
      
      const description = document.createElement('p');
      description.textContent = feature.desc;
      description.style.cssText = 'margin:0 0 20px 0; color:#aaa; font-size:0.9em;';
      container.appendChild(description);
      
      // Create input fields for each parameter
      paramKeys.forEach(key => {
        const param = params[key];
        
        const label = document.createElement('label');
        label.textContent = param.name + ':';
        label.style.cssText = 'display:block; margin-bottom:5px; font-weight:600; font-size:0.9em; color:#667eea;';
        container.appendChild(label);
        
        const input = document.createElement('input');
        input.type = param.type || 'text';
        input.placeholder = param.placeholder;
        input.name = key;
        input.style.cssText = 'width:100%; padding:10px; margin-bottom:15px; background:#1a1c2e; border:1px solid #404456; color:#fff; border-radius:6px; font-family:inherit; box-sizing:border-box;';
        container.appendChild(input);
        
        formData[key] = input;
      });
      
      // Buttons
      const buttonContainer = document.createElement('div');
      buttonContainer.style.cssText = 'display:flex; gap:10px; margin-top:20px;';
      
      const submitBtn = document.createElement('button');
      submitBtn.textContent = 'Buka API';
      submitBtn.style.cssText = 'flex:1; padding:10px 15px; background:#2196f3; color:#fff; border:none; border-radius:6px; cursor:pointer; font-weight:600; transition:all 0.2s;';
      submitBtn.onmouseover = () => submitBtn.style.background = '#1976d2';
      submitBtn.onmouseout = () => submitBtn.style.background = '#2196f3';
      submitBtn.onclick = () => {
        // Validate inputs
        const values = {};
        let valid = true;
        
        Object.entries(formData).forEach(([key, input]) => {
          const val = input.value.trim();
          if (!val) {
            input.style.borderColor = '#ff4d4f';
            valid = false;
          } else {
            values[key] = val;
          }
        });
        
        if (!valid) {
          alert('⚠️ Mohon isi semua parameter!');
          return;
        }
        
        // Build URL with parameters
        let url = path + '?apikey=' + encodeURIComponent(apiKey);
        Object.entries(values).forEach(([key, val]) => {
          url += '&' + key + '=' + encodeURIComponent(val);
        });
        
        // Close modal and open URL
        document.body.removeChild(container);
        if (overlay) document.body.removeChild(overlay);
        window.open(url, '_blank');
      };
      buttonContainer.appendChild(submitBtn);
      
      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'Batal';
      cancelBtn.style.cssText = 'flex:1; padding:10px 15px; background:#555; color:#fff; border:none; border-radius:6px; cursor:pointer; font-weight:600; transition:all 0.2s;';
      cancelBtn.onmouseover = () => cancelBtn.style.background = '#666';
      cancelBtn.onmouseout = () => cancelBtn.style.background = '#555';
      cancelBtn.onclick = () => {
        document.body.removeChild(container);
        if (overlay) document.body.removeChild(overlay);
      };
      buttonContainer.appendChild(cancelBtn);
      
      container.appendChild(buttonContainer);
      
      // Create overlay
      const overlay = document.createElement('div');
      overlay.style.cssText = 'position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.7); z-index:10000; display:flex; align-items:center; justify-content:center;';
      overlay.onclick = (e) => {
        if (e.target === overlay) {
          document.body.removeChild(container);
          document.body.removeChild(overlay);
        }
      };
      
      container.style.cssText += '; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); z-index:10001; max-width:450px; width:90%;';
      
      document.body.appendChild(overlay);
      document.body.appendChild(container);
      
      // Focus first input
      const firstInput = Object.values(formData)[0];
      if (firstInput) setTimeout(() => firstInput.focus(), 100);
    },

    /**
     * Show modal to input search query (legacy)
     */
    showSearchQueryModal: function(path, apiKey) {
      const queryInput = prompt('Masukkan kata kunci pencarian:');
      if (!queryInput || queryInput.trim() === '') {
        return;
      }

      const urlWithParams = path + (path.includes('?') ? '&' : '?') + 'apikey=' + encodeURIComponent(apiKey) + '&query=' + encodeURIComponent(queryInput);
      window.open(urlWithParams, '_blank');
    }
  };

  // Auto initialize when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      SearchFeature.init();
    });
  } else {
    SearchFeature.init();
  }
})();
