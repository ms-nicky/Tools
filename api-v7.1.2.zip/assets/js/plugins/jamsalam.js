let text_el = document.querySelector('div#browser_info');
let hSalam = document.querySelector('div#browser_sholat');
setInterval(() => {
	try {
		const d = new Date();
		const jam = d.getHours().toString().padStart(2, '0');
		const menit = d.getMinutes().toString().padStart(2, '0');
		const detik = d.getSeconds().toString().padStart(2, '0');
		// Determine greeting based on hour
		const hour = d.getHours();
		if (hSalam) {
			if (hour < 4) hSalam.textContent = 'Selamat Malam';
			else if (hour < 11) hSalam.textContent = 'Selamat Pagi';
			else if (hour < 16) hSalam.textContent = 'Selamat Siang';
			else if (hour < 20) hSalam.textContent = 'Selamat Sore';
			else hSalam.textContent = 'NICKY';
		}
		if (text_el) text_el.textContent = jam + ':' + menit + ':' + detik;
	} catch (e) { /* ignore errors */ }
}, 250);