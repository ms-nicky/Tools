
    const textnya = document.querySelector('.status');
    const warn = document.querySelector('.warn');
    var apikey = document.getElementById("responapikeymucoooookkk")
    const amlert = document.querySelector('.alert-danger');
    apikey.addEventListener("keyup", function (event) {
    if (event.key == 'Enter') {
        event.preventDefault();
        document.getElementById("diklikcok").click();
      }
    });

    function sendata() {
      if (apikey.value == '') {
        alert("Masukkan apikeymu!", "", "error");
      } else {
        var xhr = new XMLHttpRequest();
        var url = `/api/cekapikey?apikey=${apikey.value}`;
        xhr.onloadend = function () {

          data = JSON.parse(this.responseText);
          if (data.status == true) {
            // Build status text safely (avoid injecting HTML)
            const lines = [];
            lines.push('[ INFO ] Status Apikey anda adalah Active');
            lines.push('Ip: ' + (data.response.ip || '-'));
            lines.push('nama: ' + (data.response.name || '-'));
            lines.push('email: ' + (data.response.email || '-'));
            lines.push('apikey: ' + (data.response.apikey || '-'));
            lines.push('totalhit: ' + (data.response.totalhit || '-'));
            lines.push('premium: ' + (data.response.premium || '-'));
            lines.push('expired: ' + (data.response.expired || '-'));
            textnya.textContent = lines.join('\n');

            swal("Apikey valid!", 'Status Apikey anda adalah Active', "success");
            warn.textContent = ''
          } else {
            textnya.textContent = '[ INFO ] Apikey anda tidak valid!'
            swal("Apikey Tidak Valid!", "", "error");
            alert('Apikey Tidak Valid. Silahkan beli apikey ke Instagram @NICKY');
            amlert.classList.remove('hideop')
          }
        };
        xhr.open("GET", url, true);
        xhr.send();
      }
    } 