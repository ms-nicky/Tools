/**
 * Search Feature - Update Log & Test Cases
 * Version 2.0 - Extended with Sub-endpoints
 */

// Update Summary
const UPDATE_SUMMARY = {
  version: '2.0',
  date: 'December 5, 2025',
  changes: [
    'Added 60+ searchable features (was 15)',
    'Added all sub-endpoints for Cecan, Anime, Search, NSFW, Random, Stiker, Others',
    'Removed duplicate inline script from index.ejs',
    'Centralized feature management in search-feature.js',
    'Updated documentation with all features',
    'Features now grouped by category'
  ]
};

// Feature Statistics
const FEATURE_STATS = {
  main: 4,
  cecan: 7,
  search: 3,
  nsfw: 5,
  random: 7,
  stiker: 5,
  anime: 11,
  other: 5,
  tools: 2,
  total: 60
};

// Test Cases for Common Searches
const SEARCH_TESTS = [
  // Main searches
  { query: 'dashboard', expect: 'Dashboard' },
  { query: 'home', expect: 'Home' },
  { query: 'profile', expect: 'Profile' },
  
  // Category searches
  { query: 'cecan', expect: 'Cecan' }, // Multiple results
  { query: 'anime', expect: 'Anime' }, // Multiple results
  { query: 'random', expect: 'Random' }, // Multiple results
  
  // Specific searches
  { query: 'elaina', expect: 'Elaina' },
  { query: 'waifu', expect: 'Waifu' },
  { query: 'neko', expect: 'Neko' },
  { query: 'china', expect: 'China' },
  { query: 'vietnam', expect: 'Vietnam' },
  
  // Feature searches
  { query: 'download', expect: 'Download' },
  { query: 'news', expect: 'News' },
  { query: 'nsfw', expect: 'NSFW' },
  { query: 'stiker', expect: 'Stiker' },
  { query: 'upload', expect: 'Upload' },
  
  // Path searches
  { query: '/api/anime/elaina', expect: 'Elaina' },
  { query: '/anime', expect: 'Anime' },
  { query: '/docs', expect: 'Dashboard' },
  
  // Description searches
  { query: 'karakter', expect: 'Anime' }, // Multiple results
  { query: 'wallpaper', expect: 'Wallpaper' }, // Multiple results
];

// Browser console test runner
window.SearchFeatureTest = {
  
  // Run all tests
  runAll: function() {
    console.clear();
    console.log('%c🧪 Search Feature Test Suite v2.0', 'font-size: 16px; font-weight: bold; color: #667eea;');
    console.log('%cDecember 5, 2025\n', 'font-style: italic; color: #888;');
    
    this.testUpdateSummary();
    this.testFeatureStats();
    this.testSearchCases();
    this.testDOM();
    
    console.log('\n%c✅ Test Suite Complete', 'font-size: 14px; font-weight: bold; color: #10b981;');
  },
  
  // Test update summary
  testUpdateSummary: function() {
    console.log('%c📋 Update Summary', 'font-size: 12px; font-weight: bold; color: #667eea;');
    console.log(`Version: ${UPDATE_SUMMARY.version}`);
    console.log(`Date: ${UPDATE_SUMMARY.date}`);
    console.log('Changes:');
    UPDATE_SUMMARY.changes.forEach((change, i) => {
      console.log(`  ${i + 1}. ${change}`);
    });
    console.log();
  },
  
  // Test feature statistics
  testFeatureStats: function() {
    console.log('%c📊 Feature Statistics', 'font-size: 12px; font-weight: bold; color: #667eea;');
    console.log('Category Distribution:');
    Object.entries(FEATURE_STATS).forEach(([category, count]) => {
      if (category !== 'total') {
        const bar = '█'.repeat(Math.ceil(count / 2));
        console.log(`  ${category.padEnd(10)} ${bar} (${count})`);
      }
    });
    console.log(`\n  TOTAL: ${FEATURE_STATS.total} features\n`);
  },
  
  // Test search cases
  testSearchCases: function() {
    console.log('%c🔍 Search Test Cases', 'font-size: 12px; font-weight: bold; color: #667eea;');
    
    if (typeof window.SearchFeature === 'undefined') {
      console.error('❌ SearchFeature not found!');
      return;
    }
    
    const features = window.SearchFeature.features;
    let passed = 0;
    let failed = 0;
    
    SEARCH_TESTS.forEach((test, idx) => {
      const query = test.query.toLowerCase();
      const filtered = features.filter(f =>
        f.name.toLowerCase().includes(query) ||
        f.desc.toLowerCase().includes(query) ||
        f.path.toLowerCase().includes(query) ||
        f.category.toLowerCase().includes(query)
      );
      
      const hasExpected = filtered.some(f => 
        f.name.toLowerCase().includes(test.expect.toLowerCase())
      );
      
      if (hasExpected) {
        console.log(`✅ "${test.query}" → Found ${filtered.length} result(s)`);
        passed++;
      } else {
        console.log(`❌ "${test.query}" → ${test.expect} NOT found`);
        failed++;
      }
    });
    
    console.log(`\nResults: ${passed}/${SEARCH_TESTS.length} passed\n`);
  },
  
  // Test DOM elements
  testDOM: function() {
    console.log('%c🎨 DOM Elements', 'font-size: 12px; font-weight: bold; color: #667eea;');
    
    const elements = [
      { selector: '#searchModal', name: 'Search Modal' },
      { selector: '#searchInput', name: 'Search Input' },
      { selector: '#searchResults', name: 'Search Results' },
      { selector: '#search-button', name: 'Search Button' }
    ];
    
    elements.forEach(el => {
      const elem = document.querySelector(el.selector);
      if (elem) {
        console.log(`✅ ${el.name}`);
      } else {
        console.log(`❌ ${el.name} - NOT FOUND`);
      }
    });
    console.log();
  },
  
  // Specific test: Elaina
  testElaina: function() {
    console.log('%c🔍 Specific Test: Elaina', 'font-size: 12px; font-weight: bold; color: #667eea;');
    
    if (typeof window.SearchFeature === 'undefined') {
      console.error('❌ SearchFeature not found!');
      return;
    }
    
    const features = window.SearchFeature.features;
    const elaina = features.find(f => f.name.toLowerCase() === 'elaina');
    
    if (elaina) {
      console.log('✅ Elaina found!');
      console.log('Details:');
      console.log(`  Name: ${elaina.name}`);
      console.log(`  Path: ${elaina.path}`);
      console.log(`  Category: ${elaina.category}`);
      console.log(`  Desc: ${elaina.desc}`);
      console.log(`\nYou can now search for "elaina" and it will appear!`);
    } else {
      console.error('❌ Elaina NOT found!');
    }
  },
  
  // List all features
  listAll: function() {
    console.log('%c📋 Complete Feature List', 'font-size: 12px; font-weight: bold; color: #667eea;');
    
    if (typeof window.SearchFeature === 'undefined') {
      console.error('❌ SearchFeature not found!');
      return;
    }
    
    const features = window.SearchFeature.features;
    const grouped = {};
    
    features.forEach(f => {
      if (!grouped[f.category]) grouped[f.category] = [];
      grouped[f.category].push(f);
    });
    
    Object.entries(grouped).forEach(([category, items]) => {
      console.log(`\n%c${category} (${items.length})`, 'font-weight: bold; color: #667eea;');
      items.forEach(f => {
        console.log(`  • ${f.name.padEnd(30)} → ${f.path}`);
      });
    });
  },
  
  // Performance test
  performanceTest: function() {
    console.log('%c⚡ Performance Test', 'font-size: 12px; font-weight: bold; color: #667eea;');
    
    if (typeof window.SearchFeature === 'undefined') {
      console.error('❌ SearchFeature not found!');
      return;
    }
    
    const features = window.SearchFeature.features;
    const queries = ['elaina', 'cecan', 'anime', 'random', 'api'];
    
    queries.forEach(q => {
      const start = performance.now();
      
      const filtered = features.filter(f =>
        f.name.toLowerCase().includes(q) ||
        f.desc.toLowerCase().includes(q) ||
        f.path.toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q)
      );
      
      const end = performance.now();
      const time = (end - start).toFixed(2);
      
      console.log(`Query "${q}": ${filtered.length} results in ${time}ms`);
    });
  }
};

console.log('%c🧪 Search Feature Test Tools Ready!', 'font-size: 14px; color: #667eea; font-weight: bold;');
console.log('%c\nAvailable commands:\nSearchFeatureTest.runAll()        - Run all tests\nSearchFeatureTest.testElaina()      - Test Elaina specifically\nSearchFeatureTest.listAll()         - List all features\nSearchFeatureTest.performanceTest() - Performance test\n', 'font-family: monospace; color: #888;');
