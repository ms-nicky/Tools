/**
 * Global Search Initializer
 * Auto-initialize search feature pada semua halaman
 * Pastikan file ini di-load SETELAH search-feature.js
 */

(function() {
  // Tunggu sampai DOM ready dan search feature loaded
  function initSearchOnPage() {
    // Check jika SearchFeature sudah tersedia
    if (typeof window.SearchFeature === 'undefined') {
      // Retry after delay
      return setTimeout(initSearchOnPage, 100);
    }

    // Replace atau upgrade existing searchModal dengan yang lebih baik
    const existingModal = document.getElementById('searchModal');
    
    if (existingModal) {
      // Ganti modal lama dengan yang baru dari SearchFeature
      // Hapus modal lama
      existingModal.parentElement.removeChild(existingModal);
    }

    // Pastikan search feature sudah di-initialize
    if (window.SearchFeature && typeof window.SearchFeature.init === 'function') {
      window.SearchFeature.init();
    }

    // Update search button jika ada
    const searchBtn = document.getElementById('search-button');
    if (searchBtn) {
      searchBtn.addEventListener('click', function(e) {
        e.preventDefault();
        if (typeof $ !== 'undefined') {
          $('#searchModal').modal('show');
        }
      });
    }

    // Alt: Ctrl+K juga bisa trigger search (handled by search-feature.js)
    console.log('✅ Global search initialized on page:', window.location.pathname);
  }

  // Wait for DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSearchOnPage);
  } else {
    initSearchOnPage();
  }
})();
