/**
 * API Key Helper - Membantu user menggunakan endpoints dengan API key
 */

(function() {
  window.APIKeyHelper = {
    
    /**
     * Generate API test URL dari path endpoint
     */
    generateTestURL: function(path, apikey) {
      if (!apikey) {
        return {
          status: 'error',
          message: 'API Key diperlukan',
          url: null
        };
      }
      
      // Jika sudah termasuk /api, gunakan sebagaimana adanya
      let endpoint = path.startsWith('/api') ? path : '/api' + (path.startsWith('/') ? path : '/' + path);
      
      // Tambahkan apikey parameter
      const url = `${endpoint}?apikey=${encodeURIComponent(apikey)}`;
      
      return {
        status: 'success',
        url: url,
        fullUrl: `${window.location.origin}${url}`,
        message: `API endpoint siap dipanggil dengan API key Anda`
      };
    },

    /**
     * Get API key dari localStorage atau input user
     */
    getAPIKey: function() {
      // Coba dari localStorage
      const stored = localStorage.getItem('userApiKey');
      if (stored) return stored;
      
      // Coba dari DOM
      const apiKeyElement = document.querySelector('[data-apikey]');
      if (apiKeyElement) return apiKeyElement.getAttribute('data-apikey');
      
      // Coba dari page content
      const apiKeyMatch = document.body.textContent.match(/apikey[:\s]*([a-f0-9\-]{36})/i);
      if (apiKeyMatch) return apiKeyMatch[1];
      
      return null;
    },

    /**
     * Tampilkan info cara menggunakan endpoint
     */
    showUsageInfo: function(featureName, endpoint, apikey) {
      const testURL = this.generateTestURL(endpoint, apikey);
      
      if (!apikey) {
        return {
          title: featureName,
          message: '❌ API Key tidak ditemukan',
          steps: [
            '1. Login ke dashboard (/users/login)',
            '2. Copy API key Anda dari dashboard',
            '3. Gunakan API key untuk memanggil endpoint'
          ],
          example: `${endpoint}?apikey=YOUR_API_KEY_HERE`
        };
      }

      return {
        title: featureName,
        message: '✅ API Key ditemukan',
        endpoint: endpoint,
        apikey: apikey,
        testUrl: testURL.fullUrl,
        curlCommand: `curl "${testURL.fullUrl}"`,
        jsExample: `
fetch('${testURL.fullUrl}')
  .then(res => res.json())
  .then(data => console.log(data))
`,
        pythonExample: `
import requests
response = requests.get('${testURL.fullUrl}')
print(response.json())
`,
        steps: [
          `1. Endpoint: ${endpoint}`,
          `2. API Key: ${apikey.substring(0, 8)}...${apikey.substring(-4)}`,
          `3. Test URL: ${testURL.fullUrl}`,
          '4. Buka URL di browser atau gunakan tools seperti Postman'
        ]
      };
    },

    /**
     * Inject API Helper ke search feature
     */
    injectToSearchFeature: function() {
      if (typeof window.SearchFeature === 'undefined') return;

      // Extend search result dengan info button
      const originalRenderResults = window.SearchFeature.renderResults;
      
      window.SearchFeature.renderResults = function(query) {
        // Call original
        originalRenderResults.call(this, query);
        
        // Inject info buttons untuk API endpoints
        const items = document.querySelectorAll('.search-result-item');
        items.forEach(item => {
          const href = item.getAttribute('href');
          if (href && href.startsWith('/api')) {
            // Create info button
            const infoBtn = document.createElement('button');
            infoBtn.className = 'api-info-btn';
            infoBtn.innerHTML = '<i class="tim-icons icon-info-52"></i>';
            infoBtn.title = 'Lihat cara menggunakan endpoint ini';
            infoBtn.addEventListener('click', (e) => {
              e.preventDefault();
              e.stopPropagation();
              
              const featureName = item.querySelector('div').textContent;
              const apikey = window.APIKeyHelper.getAPIKey();
              const info = window.APIKeyHelper.showUsageInfo(featureName, href, apikey);
              
              window.APIKeyHelper.showInfoModal(info);
            });
            
            infoBtn.style.cssText = `
              background: rgba(102, 126, 234, 0.2);
              border: 1px solid rgba(102, 126, 234, 0.3);
              color: #667eea;
              border-radius: 4px;
              padding: 6px 10px;
              cursor: pointer;
              font-size: 0.9em;
              transition: all 0.2s;
              margin-left: 8px;
            `;
            
            infoBtn.addEventListener('mouseover', function() {
              this.style.background = 'rgba(102, 126, 234, 0.3)';
              this.style.borderColor = 'rgba(102, 126, 234, 0.5)';
            });
            
            infoBtn.addEventListener('mouseout', function() {
              this.style.background = 'rgba(102, 126, 234, 0.2)';
              this.style.borderColor = 'rgba(102, 126, 234, 0.3)';
            });
            
            // Append to item
            item.style.justifyContent = 'space-between';
            item.appendChild(infoBtn);
          }
        });
      };
    },

    /**
     * Show modal dengan informasi cara menggunakan API
     */
    showInfoModal: function(info) {
      // Create modal
      const modal = document.createElement('div');
      modal.className = 'api-info-modal';
      modal.innerHTML = `
        <div class="modal-overlay"></div>
        <div class="modal-content">
          <div class="modal-header">
            <h3>${info.title || 'API Information'}</h3>
            <button class="close-btn">&times;</button>
          </div>
          <div class="modal-body">
            <div class="info-section">
              <h4>Status</h4>
              <p class="status-message">${info.message}</p>
            </div>
            
            ${info.apikey ? `
              <div class="info-section">
                <h4>API Key</h4>
                <div class="key-display">
                  <code>${info.apikey.substring(0, 8)}...${info.apikey.substring(-4)}</code>
                  <button class="copy-btn" data-copy="${info.apikey}">Copy</button>
                </div>
              </div>
              
              <div class="info-section">
                <h4>Test URL</h4>
                <div class="url-display">
                  <code>${info.testUrl}</code>
                  <button class="copy-btn" data-copy="${info.testUrl}">Copy</button>
                </div>
                <a href="${info.testUrl}" target="_blank" class="test-btn">Buka di Tab Baru</a>
              </div>
              
              <div class="info-section">
                <h4>cURL Command</h4>
                <pre><code>${this.escapeHtml(info.curlCommand)}</code></pre>
                <button class="copy-btn" data-copy="${info.curlCommand}">Copy</button>
              </div>
              
              <div class="info-section">
                <h4>JavaScript</h4>
                <pre><code>${this.escapeHtml(info.jsExample)}</code></pre>
                <button class="copy-btn" data-copy="${info.jsExample}">Copy</button>
              </div>
              
              <div class="info-section">
                <h4>Python</h4>
                <pre><code>${this.escapeHtml(info.pythonExample)}</code></pre>
                <button class="copy-btn" data-copy="${info.pythonExample}">Copy</button>
              </div>
            ` : `
              <div class="info-section">
                <h4>Langkah-langkah</h4>
                <ol>
                  ${info.steps.map(step => `<li>${step}</li>`).join('')}
                </ol>
              </div>
            `}
          </div>
        </div>
      `;
      
      // Add styles
      const style = document.createElement('style');
      style.textContent = `
        .api-info-modal {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 10000;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .api-info-modal .modal-overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.7);
          cursor: pointer;
        }
        
        .api-info-modal .modal-content {
          position: relative;
          background: #27293d;
          border: 1px solid #404456;
          border-radius: 12px;
          max-width: 700px;
          max-height: 80vh;
          overflow-y: auto;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }
        
        .api-info-modal .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem;
          border-bottom: 1px solid #404456;
          position: sticky;
          top: 0;
          background: #27293d;
        }
        
        .api-info-modal .modal-header h3 {
          margin: 0;
          color: #fff;
          font-size: 1.3em;
        }
        
        .api-info-modal .close-btn {
          background: none;
          border: none;
          color: #fff;
          font-size: 1.5em;
          cursor: pointer;
          opacity: 0.7;
          transition: opacity 0.2s;
        }
        
        .api-info-modal .close-btn:hover {
          opacity: 1;
        }
        
        .api-info-modal .modal-body {
          padding: 1.5rem;
        }
        
        .api-info-modal .info-section {
          margin-bottom: 1.5rem;
        }
        
        .api-info-modal .info-section h4 {
          color: #667eea;
          font-weight: 600;
          margin: 0 0 0.8rem 0;
          font-size: 0.95em;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .api-info-modal .info-section p,
        .api-info-modal .info-section ol {
          color: #aaa;
          margin: 0 0 0.5rem 0;
          line-height: 1.6;
        }
        
        .api-info-modal .info-section ol {
          padding-left: 1.5rem;
        }
        
        .api-info-modal .info-section li {
          margin-bottom: 0.5rem;
        }
        
        .api-info-modal .status-message {
          padding: 0.8rem;
          border-radius: 6px;
          font-weight: 500;
          background: rgba(16, 185, 129, 0.1);
          border-left: 3px solid #10b981;
          color: #10b981;
        }
        
        .api-info-modal .status-message.error {
          background: rgba(220, 53, 69, 0.1);
          border-left-color: #dc3545;
          color: #dc3545;
        }
        
        .api-info-modal .key-display,
        .api-info-modal .url-display {
          display: flex;
          gap: 0.8rem;
          align-items: center;
          background: #1a1c2e;
          padding: 0.8rem;
          border-radius: 6px;
          margin-bottom: 0.8rem;
        }
        
        .api-info-modal code {
          background: #1a1c2e;
          color: #667eea;
          padding: 0.2rem 0.5rem;
          border-radius: 4px;
          font-family: 'Courier New', monospace;
          font-size: 0.9em;
          flex: 1;
          overflow: auto;
          word-break: break-all;
        }
        
        .api-info-modal pre {
          background: #1a1c2e;
          border: 1px solid #404456;
          padding: 1rem;
          border-radius: 6px;
          overflow-x: auto;
          margin: 0.8rem 0;
        }
        
        .api-info-modal pre code {
          background: none;
          color: #10b981;
          padding: 0;
          font-size: 0.85em;
          line-height: 1.4;
        }
        
        .api-info-modal .copy-btn,
        .api-info-modal .test-btn {
          background: #667eea;
          color: #fff;
          border: none;
          padding: 0.5rem 1rem;
          border-radius: 4px;
          cursor: pointer;
          font-size: 0.85em;
          font-weight: 600;
          transition: background 0.2s;
        }
        
        .api-info-modal .copy-btn:hover,
        .api-info-modal .test-btn:hover {
          background: #764ba2;
        }
        
        .api-info-modal .test-btn {
          display: inline-block;
          margin-top: 0.8rem;
        }
        
        @media (max-width: 768px) {
          .api-info-modal .modal-content {
            max-width: 90vw;
          }
        }
      `;
      
      document.head.appendChild(style);
      document.body.appendChild(modal);
      
      // Event listeners
      const closeBtn = modal.querySelector('.close-btn');
      const overlay = modal.querySelector('.modal-overlay');
      
      closeBtn.addEventListener('click', () => modal.remove());
      overlay.addEventListener('click', () => modal.remove());
      
      // Copy buttons
      modal.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const text = btn.getAttribute('data-copy');
          navigator.clipboard.writeText(text).then(() => {
            const original = btn.textContent;
            btn.textContent = '✓ Copied!';
            setTimeout(() => {
              btn.textContent = original;
            }, 2000);
          });
        });
      });
      
      // Escape key
      document.addEventListener('keydown', function escapeListener(e) {
        if (e.key === 'Escape') {
          modal.remove();
          document.removeEventListener('keydown', escapeListener);
        }
      });
    },

    /**
     * Escape HTML
     */
    escapeHtml: function(text) {
      const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      };
      return text.replace(/[&<>"']/g, m => map[m]);
    }
  };

  // Auto-inject when SearchFeature ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      // Auto-save API key from profile page
      var apikeyInput = document.getElementById('apikey');
      if (apikeyInput && apikeyInput.value) {
        localStorage.setItem('apikey', apikeyInput.value);
      }
      
      if (typeof window.SearchFeature !== 'undefined') {
        window.APIKeyHelper.injectToSearchFeature();
      }
    });
  } else {
    // Auto-save API key from profile page
    var apikeyInput = document.getElementById('apikey');
    if (apikeyInput && apikeyInput.value) {
      localStorage.setItem('apikey', apikeyInput.value);
    }
    
    if (typeof window.SearchFeature !== 'undefined') {
      window.APIKeyHelper.injectToSearchFeature();
    }
  }
})();
